import AsyncStorage from '@react-native-async-storage/async-storage'

const STORAGE_KEYS = {
  CONVERSATIONS: 'conversations',
  MESSAGES: 'messages',
  EMOTION_ENTRIES: 'emotion_entries',
  USER_PROFILE: 'user_profile',
  DAILY_TASKS: 'daily_tasks',
  SYNC_QUEUE: 'sync_queue',
}

export const storage = {
  // Conversations
  async saveConversations(conversations: any[]) {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.CONVERSATIONS,
        JSON.stringify(conversations)
      )
    } catch (error) {
      console.error('Error saving conversations:', error)
    }
  },

  async getConversations() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.CONVERSATIONS)
      return data ? JSON.parse(data) : []
    } catch (error) {
      console.error('Error getting conversations:', error)
      return []
    }
  },

  // Messages
  async saveMessages(conversationId: string, messages: any[]) {
    try {
      const key = `${STORAGE_KEYS.MESSAGES}_${conversationId}`
      await AsyncStorage.setItem(key, JSON.stringify(messages))
    } catch (error) {
      console.error('Error saving messages:', error)
    }
  },

  async getMessages(conversationId: string) {
    try {
      const key = `${STORAGE_KEYS.MESSAGES}_${conversationId}`
      const data = await AsyncStorage.getItem(key)
      return data ? JSON.parse(data) : []
    } catch (error) {
      console.error('Error getting messages:', error)
      return []
    }
  },

  // Emotion Entries
  async saveEmotionEntries(entries: any[]) {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.EMOTION_ENTRIES,
        JSON.stringify(entries)
      )
    } catch (error) {
      console.error('Error saving emotion entries:', error)
    }
  },

  async getEmotionEntries() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.EMOTION_ENTRIES)
      return data ? JSON.parse(data) : []
    } catch (error) {
      console.error('Error getting emotion entries:', error)
      return []
    }
  },

  // User Profile
  async saveUserProfile(profile: any) {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.USER_PROFILE,
        JSON.stringify(profile)
      )
    } catch (error) {
      console.error('Error saving user profile:', error)
    }
  },

  async getUserProfile() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.USER_PROFILE)
      return data ? JSON.parse(data) : null
    } catch (error) {
      console.error('Error getting user profile:', error)
      return null
    }
  },

  // Daily Tasks
  async saveDailyTasks(tasks: any) {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.DAILY_TASKS,
        JSON.stringify(tasks)
      )
    } catch (error) {
      console.error('Error saving daily tasks:', error)
    }
  },

  async getDailyTasks() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.DAILY_TASKS)
      return data ? JSON.parse(data) : null
    } catch (error) {
      console.error('Error getting daily tasks:', error)
      return null
    }
  },

  // Sync Queue
  async addToSyncQueue(action: string, data: any) {
    try {
      const queue = await this.getSyncQueue()
      queue.push({ action, data, timestamp: Date.now() })
      await AsyncStorage.setItem(
        STORAGE_KEYS.SYNC_QUEUE,
        JSON.stringify(queue)
      )
    } catch (error) {
      console.error('Error adding to sync queue:', error)
    }
  },

  async getSyncQueue() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.SYNC_QUEUE)
      return data ? JSON.parse(data) : []
    } catch (error) {
      console.error('Error getting sync queue:', error)
      return []
    }
  },

  async clearSyncQueue() {
    try {
      await AsyncStorage.removeItem(STORAGE_KEYS.SYNC_QUEUE)
    } catch (error) {
      console.error('Error clearing sync queue:', error)
    }
  },

  // Clear all data
  async clearAll() {
    try {
      await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS))
    } catch (error) {
      console.error('Error clearing storage:', error)
    }
  },
}
