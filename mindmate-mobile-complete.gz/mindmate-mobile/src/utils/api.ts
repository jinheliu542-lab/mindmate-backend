import axios, { AxiosInstance } from 'axios'
import * as SecureStore from 'expo-secure-store'

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3000'

const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  timeout: parseInt(process.env.EXPO_PUBLIC_API_TIMEOUT || '30000'),
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add token to requests
api.interceptors.request.use(async (config) => {
  try {
    const token = await SecureStore.getItemAsync('auth_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
  } catch (error) {
    console.error('Error retrieving token:', error)
  }
  return config
})

// Handle errors
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await SecureStore.deleteItemAsync('auth_token')
      // Trigger logout event
      window.dispatchEvent(new Event('logout'))
    }
    return Promise.reject(error)
  }
)

export const authAPI = {
  register: (email: string, password: string, username: string) =>
    api.post('/auth/register', { email, password, username }),
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
}

export const chatAPI = {
  getConversations: () => api.get('/chat/conversations'),
  createConversation: (title?: string) =>
    api.post('/chat/conversations', { title }),
  getMessages: (conversationId: string) =>
    api.get(`/chat/conversations/${conversationId}/messages`),
  sendMessage: (conversationId: string, content: string) =>
    api.post(`/chat/conversations/${conversationId}/messages`, { content }),
}

export const userAPI = {
  getProfile: () => api.get('/user/profile'),
  updateProfile: (profile: any, emotionalProfile?: any) =>
    api.put('/user/profile', { profile, emotionalProfile }),
  getStats: () => api.get('/user/stats'),
  updateAIPersonality: (counselingStyle: string, focusAreas: string[]) =>
    api.put('/user/ai-personality', { counselingStyle, focusAreas }),
}

export const emotionAPI = {
  createEntry: (data: any) => api.post('/emotion/entries', data),
  getEntries: (startDate?: string, endDate?: string) =>
    api.get('/emotion/entries', { params: { startDate, endDate } }),
  getStats: () => api.get('/emotion/stats'),
}

export const taskAPI = {
  getTodayTasks: () => api.get('/task/today'),
  completeTask: (taskId: string) =>
    api.put(`/task/today/tasks/${taskId}/complete`),
  checkIn: () => api.post('/task/check-in'),
}

export default api
