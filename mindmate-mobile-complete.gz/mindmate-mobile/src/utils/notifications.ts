import * as Notifications from 'expo-notifications'
import * as Device from 'expo-device'
import Constants from 'expo-constants'

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
})

export async function registerForPushNotificationsAsync() {
  if (!Device.isDevice) {
    console.log('Must use physical device for push notifications')
    return
  }

  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync()
    let finalStatus = existingStatus

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync()
      finalStatus = status
    }

    if (finalStatus !== 'granted') {
      console.log('Failed to get push token for push notification!')
      return
    }

    const projectId = Constants.expoConfig?.extra?.eas?.projectId
    if (!projectId) {
      throw new Error('Project ID not found')
    }

    const token = await Notifications.getExpoPushTokenAsync({
      projectId,
    })

    return token.data
  } catch (error) {
    console.error('Error registering for push notifications:', error)
  }
}

export async function sendLocalNotification(
  title: string,
  body: string,
  delay: number = 5000
) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: 'default',
        badge: 1,
      },
      trigger: { seconds: delay / 1000 },
    })
  } catch (error) {
    console.error('Error sending notification:', error)
  }
}

export async function scheduleDailyNotification(
  title: string,
  body: string,
  hour: number = 9,
  minute: number = 0
) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: 'default',
        badge: 1,
      },
      trigger: {
        type: 'daily',
        hour,
        minute,
      },
    })
  } catch (error) {
    console.error('Error scheduling daily notification:', error)
  }
}

export function setupNotificationListeners(
  onNotificationReceived?: (notification: Notifications.Notification) => void,
  onNotificationTapped?: (response: Notifications.NotificationResponse) => void
) {
  // Handle notification received while app is in foreground
  const receivedSubscription = Notifications.addNotificationReceivedListener(
    (notification) => {
      onNotificationReceived?.(notification)
    }
  )

  // Handle notification tapped
  const responseSubscription = Notifications.addNotificationResponseReceivedListener(
    (response) => {
      onNotificationTapped?.(response)
    }
  )

  return () => {
    receivedSubscription.remove()
    responseSubscription.remove()
  }
}
