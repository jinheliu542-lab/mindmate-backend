import { create } from 'zustand'
import * as SecureStore from 'expo-secure-store'
import { authAPI } from '../utils/api'

interface User {
  id: string
  email: string
  username: string
}

interface AuthStore {
  user: User | null
  token: string | null
  isLoading: boolean
  error: string | null
  isInitialized: boolean
  register: (email: string, password: string, username: string) => Promise<void>
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  setUser: (user: User | null) => void
  setToken: (token: string | null) => void
  initializeAuth: () => Promise<void>
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  token: null,
  isLoading: false,
  error: null,
  isInitialized: false,

  initializeAuth: async () => {
    try {
      const token = await SecureStore.getItemAsync('auth_token')
      if (token) {
        set({ token, isInitialized: true })
      } else {
        set({ isInitialized: true })
      }
    } catch (error) {
      console.error('Error initializing auth:', error)
      set({ isInitialized: true })
    }
  },

  register: async (email: string, password: string, username: string) => {
    set({ isLoading: true, error: null })
    try {
      const response = await authAPI.register(email, password, username)
      const { token, user } = response.data
      await SecureStore.setItemAsync('auth_token', token)
      set({ user, token, isLoading: false })
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Registration failed'
      set({ error: errorMessage, isLoading: false })
      throw error
    }
  },

  login: async (email: string, password: string) => {
    set({ isLoading: true, error: null })
    try {
      const response = await authAPI.login(email, password)
      const { token, user } = response.data
      await SecureStore.setItemAsync('auth_token', token)
      set({ user, token, isLoading: false })
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Login failed'
      set({ error: errorMessage, isLoading: false })
      throw error
    }
  },

  logout: async () => {
    try {
      await SecureStore.deleteItemAsync('auth_token')
      set({ user: null, token: null })
    } catch (error) {
      console.error('Error during logout:', error)
    }
  },

  setUser: (user: User | null) => set({ user }),
  setToken: (token: string | null) => set({ token }),
}))
