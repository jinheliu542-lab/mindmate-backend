# MindMate 移动应用

MindMate 是一个 AI 心理咨询平台的 React Native 移动应用，支持 iOS 和 Android。

## 功能特性

- 📱 **原生移动体验**：使用 React Native + Expo 开发
- 💬 **实时 AI 咨询**：与 AI 进行实时对话咨询
- 📊 **情绪追踪**：记录和分析你的情绪变化
- 🎯 **每日任务**：完成任务解锁新功能
- 📈 **成长曲线**：可视化你的心理健康进展
- 🔔 **推送通知**：定时提醒和情绪检查
- 💾 **离线支持**：无网络时仍可使用应用
- 🔐 **安全认证**：使用 JWT 和 Secure Store

## 技术栈

- **框架**：React Native 0.73 + Expo 50
- **路由**：Expo Router 3
- **状态管理**：Zustand
- **样式**：NativeWind (Tailwind CSS)
- **API 通信**：Axios
- **本地存储**：AsyncStorage + Expo Secure Store
- **推送通知**：Expo Notifications
- **语言**：TypeScript

## 项目结构

```
mindmate-mobile/
├── app/
│   ├── _layout.tsx              # 根布局
│   ├── (auth)/                  # 认证屏幕
│   │   ├── _layout.tsx
│   │   ├── login.tsx
│   │   └── register.tsx
│   └── (app)/                   # 应用屏幕
│       ├── _layout.tsx
│       ├── (tabs)/
│       │   ├── _layout.tsx
│       │   └── index.tsx        # 首页
│       ├── chat.tsx             # 咨询屏幕
│       ├── emotions.tsx         # 情绪屏幕
│       └── profile.tsx          # 个人资料屏幕
├── src/
│   ├── utils/
│   │   ├── api.ts              # API 客户端
│   │   ├── notifications.ts    # 通知服务
│   │   └── storage.ts          # 本地存储
│   └── store/
│       └── authStore.ts        # 认证状态管理
├── app.json                     # Expo 配置
├── tailwind.config.js           # Tailwind 配置
└── tsconfig.json                # TypeScript 配置
```

## 快速开始

### 环境要求

- Node.js 18.0.0 或更高版本
- npm 9.0.0 或 pnpm 8.0.0
- Expo CLI

### 安装依赖

```bash
npm install
# 或
pnpm install
```

### 配置环境变量

```bash
cp .env.example .env
```

编辑 `.env` 文件，设置 API URL：

```env
EXPO_PUBLIC_API_URL=http://localhost:3000
```

### 启动开发服务器

```bash
npm start
```

### 在设备上运行

#### iOS

```bash
npm run ios
```

需要 Mac 和 Xcode。

#### Android

```bash
npm run android
```

需要 Android Studio 和 Android SDK。

#### 使用 Expo Go

1. 在 iOS App Store 或 Google Play 安装 Expo Go
2. 运行 `npm start`
3. 使用 Expo Go 扫描 QR 码

## 屏幕说明

### 认证屏幕

- **登录屏幕**：使用邮箱和密码登录
- **注册屏幕**：创建新账户

### 应用屏幕

#### 首页 (Home)
- 显示统计数据（对话次数、签到天数、连续签到、平均心情）
- 快速操作按钮（开始咨询、记录情绪、每日签到）
- 情绪概览

#### 咨询 (Chat)
- 与 AI 进行实时对话
- 管理多个对话
- 离线消息队列

#### 情绪 (Emotions)
- 记录每日情绪
- 选择心情和强度
- 添加备注
- 查看历史记录

#### 个人资料 (Profile)
- 用户信息
- 统计数据
- AI 咨询偏好设置
- 退出登录

## API 集成

应用通过以下 API 端点与后端通信：

### 认证
- `POST /auth/register` - 注册
- `POST /auth/login` - 登录

### 聊天
- `GET /chat/conversations` - 获取对话列表
- `POST /chat/conversations` - 创建新对话
- `GET /chat/conversations/:id/messages` - 获取消息
- `POST /chat/conversations/:id/messages` - 发送消息

### 用户
- `GET /user/profile` - 获取个人资料
- `PUT /user/profile` - 更新个人资料
- `GET /user/stats` - 获取统计数据
- `PUT /user/ai-personality` - 更新 AI 个性化设置

### 情绪
- `POST /emotion/entries` - 创建情绪记录
- `GET /emotion/entries` - 获取情绪记录
- `GET /emotion/stats` - 获取情绪统计

### 任务
- `GET /task/today` - 获取今日任务
- `PUT /task/today/tasks/:id/complete` - 完成任务
- `POST /task/check-in` - 每日签到

## 离线支持

应用支持基本的离线功能：

- 查看缓存的对话和消息
- 离线时排队消息，在线后自动同步
- 本地存储情绪记录

## 推送通知

应用支持以下推送通知：

- 每日情绪提醒
- 签到提醒
- 新消息通知

## 安全性

- JWT 令牌存储在 Secure Store 中
- API 请求自动附加认证令牌
- 401 错误时自动退出登录

## 构建和发布

### 构建 APK (Android)

```bash
eas build --platform android
```

### 构建 IPA (iOS)

```bash
eas build --platform ios
```

### 发布到应用商店

```bash
eas submit --platform android
eas submit --platform ios
```

## 故障排除

### 问题：应用无法连接到 API

**解决方案**：
1. 检查 `.env` 中的 `EXPO_PUBLIC_API_URL` 是否正确
2. 确保后端服务器正在运行
3. 检查网络连接

### 问题：推送通知不工作

**解决方案**：
1. 确保在 `app.json` 中配置了 EAS 项目 ID
2. 检查设备是否允许通知权限
3. 查看 Expo 文档中的通知配置

### 问题：离线模式无法工作

**解决方案**：
1. 检查 AsyncStorage 是否正确初始化
2. 确保数据已保存到本地存储
3. 查看浏览器控制台中的错误

## 性能优化

- 使用 FlatList 而不是 ScrollView 处理长列表
- 实现消息虚拟化以提高聊天性能
- 缓存 API 响应以减少网络请求
- 使用 React.memo 优化组件重新渲染

## 贡献

欢迎贡献！请提交 Pull Request 或报告问题。

## 许可证

MIT License

## 支持

如有问题，请查看：
- [Expo 文档](https://docs.expo.dev)
- [React Native 文档](https://reactnative.dev)
- [项目 GitHub Issues](https://github.com/mindmate/mobile)

---

祝您使用愉快！
