# MindMate APK 构建和安装指南

本指南专为**没有电脑的用户**设计，所有步骤都可以在手机浏览器上完成。

## 📱 APK 构建流程

```
1. 准备工作 (5分钟)
   ↓
2. 上传代码到 GitHub (5分钟)
   ↓
3. 在 Expo 中构建 APK (15分钟，自动进行)
   ↓
4. 下载 APK 到手机 (2分钟)
   ↓
5. 安装 APK (1分钟)
```

---

## 步骤 1：准备工作（5分钟）

### 获取必要账户

1. **Expo 账户**
   - 访问：https://expo.dev
   - 点击 "Sign up"
   - 使用邮箱注册
   - 验证邮箱

2. **GitHub 账户**（如果还没有）
   - 访问：https://github.com
   - 点击 "Sign up"
   - 使用邮箱注册

---

## 步骤 2：上传代码到 GitHub（5分钟）

1. **创建新仓库**
   - 登录 GitHub
   - 点击 "+" → "New repository"
   - 仓库名：`mindmate-mobile`
   - 选择 "Public"
   - 点击 "Create repository"

2. **上传移动应用代码**
   - 点击 "Add file" → "Upload files"
   - 上传 `/home/ubuntu/mindmate-mobile` 中的所有文件
   - 包括：
     - `app/` 文件夹
     - `src/` 文件夹
     - `app.json`
     - `package.json`
     - `eas.json`
     - 等等
   - 点击 "Commit changes"

3. **添加环境配置**
   - 在仓库中创建 `.env.production` 文件
   - 内容：

   ```
   EXPO_PUBLIC_API_URL=https://mindmate-api.railway.app
   EXPO_PUBLIC_APP_NAME=MindMate
   EXPO_PUBLIC_APP_VERSION=1.0.0
   EXPO_PUBLIC_ENABLE_NOTIFICATIONS=true
   EXPO_PUBLIC_ENABLE_OFFLINE_MODE=true
   EXPO_PUBLIC_DEBUG_MODE=false
   ```

   - 替换 API URL 为您的 Railway 后端 URL
   - 点击 "Commit new file"

---

## 步骤 3：在 Expo 中构建 APK（15分钟）

### 方法 A：使用 Expo 网站（推荐）

1. **登录 Expo**
   - 访问：https://expo.dev
   - 点击 "Sign in"
   - 使用您的 Expo 账户登录

2. **创建新项目**
   - 点击 "Create"
   - 选择 "From GitHub"
   - 授权 Expo 访问 GitHub
   - 选择 `mindmate-mobile` 仓库

3. **配置项目**
   - 项目名称：`mindmate`
   - 点击 "Create project"

4. **触发构建**
   - 进入项目
   - 点击 "Build"
   - 选择 "Android"
   - 选择 "APK"
   - 点击 "Build"

5. **等待构建**
   - 构建通常需要 10-15 分钟
   - 您可以关闭浏览器，稍后回来检查
   - Expo 会发送邮件通知构建完成

### 方法 B：使用 Expo CLI（如果有电脑）

```bash
cd mindmate-mobile
eas build --platform android --type apk
```

---

## 步骤 4：下载 APK 到手机（2分钟）

### 在 Expo 网站上

1. **查看构建状态**
   - 登录 Expo
   - 进入 `mindmate` 项目
   - 在 "Builds" 标签中查看构建列表

2. **下载 APK**
   - 找到已完成的构建
   - 点击 "Download"
   - APK 会下载到手机的 Downloads 文件夹

3. **或使用二维码**
   - 构建完成后，Expo 会显示二维码
   - 用手机扫描二维码
   - 直接下载 APK

---

## 步骤 5：安装 APK（1分钟）

### 在 Android 手机上

1. **打开文件管理器**
   - 找到 "Files" 或 "文件管理器" 应用
   - 进入 "Downloads" 文件夹
   - 找到 `mindmate-*.apk` 文件

2. **点击 APK 文件**
   - 系统会提示 "安装应用"
   - 点击 "安装"

3. **允许安装**
   - 如果提示 "未知来源"
   - 点击 "允许" 或 "设置"
   - 启用 "允许安装未知来源的应用"
   - 返回并点击 "安装"

4. **等待安装**
   - 安装通常需要 10-30 秒
   - 安装完成后，点击 "打开"

5. **首次启动**
   - 应用会启动
   - 您会看到登录屏幕
   - 点击 "注册" 创建账户

---

## 🎯 安装后的配置

### 首次启动

1. **创建账户**
   - 输入邮箱
   - 输入用户名
   - 输入密码（至少 6 个字符）
   - 点击 "注册"

2. **配置 API**（如果需要）
   - 进入 "Profile" → "Settings"
   - 确认 API URL 是正确的
   - 应该是：`https://mindmate-api.railway.app`

3. **开始使用**
   - 登录成功后，进入首页
   - 点击 "开始咨询" 与 AI 对话
   - 点击 "记录情绪" 记录心情

---

## 📋 检查清单

在构建前，确保：

- [ ] 代码已上传到 GitHub
- [ ] `eas.json` 文件存在
- [ ] `app.json` 文件正确配置
- [ ] `.env.production` 包含正确的 API URL
- [ ] Expo 账户已创建
- [ ] GitHub 仓库是 Public 的

---

## ❓ 常见问题

### Q1: 构建失败了怎么办？

**检查清单**：
1. ✅ GitHub 仓库中是否包含所有必要文件
2. ✅ `package.json` 是否正确
3. ✅ `app.json` 是否正确
4. ✅ `eas.json` 是否存在
5. ✅ 查看 Expo 的构建日志找出错误

**查看日志**：
- 在 Expo 中点击构建
- 点击 "View logs"
- 查看错误信息

### Q2: APK 无法安装

**原因和解决方案**：

| 问题 | 解决方案 |
|------|---------|
| "未知来源" 提示 | 在设置中启用 "允许安装未知来源的应用" |
| "解析包失败" | 重新下载 APK，可能下载损坏 |
| "存储空间不足" | 清理手机存储空间（删除不需要的文件） |
| "不兼容" | 确保 Android 版本 5.0 或更高 |

### Q3: 应用启动后无法连接到后端

**检查**：
1. 确认 Railway 后端正在运行
2. 确认 API URL 正确
3. 检查网络连接
4. 在应用设置中重新输入 API URL

### Q4: 如何更新应用？

1. 在 GitHub 中更新代码
2. 在 Expo 中重新构建
3. 下载新的 APK
4. 卸载旧版本
5. 安装新版本

### Q5: 如何卸载应用？

1. 长按应用图标
2. 选择 "卸载"
3. 确认卸载

---

## 🔐 安全提示

1. **只从官方来源下载**
   - 只从 Expo 官方网站下载 APK
   - 不要从第三方网站下载

2. **检查文件大小**
   - APK 文件大小应该在 50-150 MB
   - 如果太小或太大，可能有问题

3. **定期更新**
   - 定期检查应用更新
   - 及时安装安全补丁

---

## 📊 APK 信息

| 项目 | 信息 |
|------|------|
| 应用名称 | MindMate |
| 包名 | com.mindmate.counselor |
| 最小 Android 版本 | 5.0 (API 21) |
| 目标 Android 版本 | 14.0 (API 34) |
| 文件大小 | ~80-100 MB |

---

## 🚀 构建优化

如果构建速度慢：

1. **清除缓存**
   - 在 Expo 中点击 "Clear cache"
   - 重新构建

2. **检查网络**
   - 确保网络连接稳定
   - 在 WiFi 环境下构建

3. **等待队列**
   - Expo 可能有构建队列
   - 稍后重试

---

## 📞 获取帮助

- **Expo 文档**：https://docs.expo.dev
- **Expo 论坛**：https://forums.expo.dev
- **GitHub Issues**：在仓库中提交 Issue

---

**构建完成！🎉**

现在您可以在手机上使用 MindMate 了！
