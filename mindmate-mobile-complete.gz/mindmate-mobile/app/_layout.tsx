import { useEffect } from 'react'
import { Stack } from 'expo-router'
import * as SplashScreen from 'expo-splash-screen'
import { useAuthStore } from '@/store/authStore'
import { setupNotificationListeners, registerForPushNotificationsAsync } from '@/utils/notifications'

SplashScreen.preventAutoHideAsync()

export default function RootLayout() {
  const { isInitialized, initializeAuth } = useAuthStore()

  useEffect(() => {
    const prepare = async () => {
      try {
        // Initialize auth
        await initializeAuth()

        // Register for push notifications
        await registerForPushNotificationsAsync()

        // Setup notification listeners
        setupNotificationListeners()

        // Hide splash screen
        await SplashScreen.hideAsync()
      } catch (error) {
        console.error('Error preparing app:', error)
        await SplashScreen.hideAsync()
      }
    }

    prepare()
  }, [])

  if (!isInitialized) {
    return null
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animationEnabled: true,
      }}
    >
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      <Stack.Screen name="(app)" options={{ headerShown: false }} />
    </Stack>
  )
}
