import { useState } from 'react'
import { View, Text, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native'
import { useRouter, Link } from 'expo-router'
import { useAuthStore } from '@/store/authStore'

export default function RegisterScreen() {
  const router = useRouter()
  const { register, isLoading, error } = useAuthStore()
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [validationError, setValidationError] = useState('')

  const handleRegister = async () => {
    if (password !== confirmPassword) {
      setValidationError('密码不匹配')
      return
    }

    if (password.length < 6) {
      setValidationError('密码至少需要6个字符')
      return
    }

    try {
      await register(email, password, username)
      router.replace('/(app)/(tabs)')
    } catch (err) {
      // Error is handled by the store
    }
  }

  return (
    <ScrollView className="flex-1 bg-white">
      <View className="flex-1 px-6 py-12">
        {/* Header */}
        <View className="mb-8 mt-4">
          <Text className="text-4xl font-bold text-gray-800 mb-2">MindMate</Text>
          <Text className="text-gray-600">创建账户开始咨询</Text>
        </View>

        {/* Error Messages */}
        {(error || validationError) && (
          <View className="bg-red-50 border border-red-200 rounded-lg p-3 mb-6">
            <Text className="text-red-700 text-sm">{error || validationError}</Text>
          </View>
        )}

        {/* Username Input */}
        <View className="mb-4">
          <Text className="text-sm font-medium text-gray-700 mb-2">用户名</Text>
          <TextInput
            className="border border-gray-300 rounded-lg px-4 py-3 text-base"
            placeholder="your_username"
            placeholderTextColor="#9ca3af"
            value={username}
            onChangeText={setUsername}
            editable={!isLoading}
          />
        </View>

        {/* Email Input */}
        <View className="mb-4">
          <Text className="text-sm font-medium text-gray-700 mb-2">邮箱</Text>
          <TextInput
            className="border border-gray-300 rounded-lg px-4 py-3 text-base"
            placeholder="your@email.com"
            placeholderTextColor="#9ca3af"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
            editable={!isLoading}
          />
        </View>

        {/* Password Input */}
        <View className="mb-4">
          <Text className="text-sm font-medium text-gray-700 mb-2">密码</Text>
          <TextInput
            className="border border-gray-300 rounded-lg px-4 py-3 text-base"
            placeholder="••••••••"
            placeholderTextColor="#9ca3af"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            editable={!isLoading}
          />
        </View>

        {/* Confirm Password Input */}
        <View className="mb-6">
          <Text className="text-sm font-medium text-gray-700 mb-2">确认密码</Text>
          <TextInput
            className="border border-gray-300 rounded-lg px-4 py-3 text-base"
            placeholder="••••••••"
            placeholderTextColor="#9ca3af"
            secureTextEntry
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            editable={!isLoading}
          />
        </View>

        {/* Register Button */}
        <TouchableOpacity
          className="bg-primary-500 rounded-lg py-3 mb-4"
          onPress={handleRegister}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text className="text-white text-center font-semibold text-base">注册</Text>
          )}
        </TouchableOpacity>

        {/* Login Link */}
        <View className="flex-row justify-center items-center">
          <Text className="text-gray-600">已有账户? </Text>
          <Link href="/(auth)/login" asChild>
            <TouchableOpacity>
              <Text className="text-primary-500 font-semibold">登录</Text>
            </TouchableOpacity>
          </Link>
        </View>
      </View>
    </ScrollView>
  )
}
