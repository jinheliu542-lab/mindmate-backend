import { useState, useEffect } from 'react'
import { View, Text, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useAuthStore } from '@/store/authStore'
import { userAPI, taskAPI, emotionAPI } from '@/utils/api'

export default function HomeScreen() {
  const { user } = useAuthStore()
  const [stats, setStats] = useState<any>(null)
  const [emotionStats, setEmotionStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsRes, emotionRes] = await Promise.all([
          userAPI.getStats(),
          emotionAPI.getStats(),
        ])
        setStats(statsRes.data)
        setEmotionStats(emotionRes.data)
      } catch (error) {
        console.error('Failed to fetch data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <ScrollView className="flex-1">
        {/* Header */}
        <View className="px-4 py-6 bg-white border-b border-gray-200">
          <Text className="text-3xl font-bold text-gray-800">
            欢迎回来, {user?.username}!
          </Text>
          <Text className="text-gray-600 mt-1">今天感觉如何?</Text>
        </View>

        {loading ? (
          <View className="flex-1 justify-center items-center py-12">
            <ActivityIndicator size="large" color="#0ea5e9" />
          </View>
        ) : (
          <>
            {/* Stats Cards */}
            <View className="px-4 py-6 space-y-3">
              <View className="flex-row justify-between gap-3">
                <View className="flex-1 bg-white rounded-lg p-4">
                  <Text className="text-gray-600 text-xs font-medium mb-2">总对话次数</Text>
                  <Text className="text-2xl font-bold text-primary-600">
                    {stats?.totalChats || 0}
                  </Text>
                </View>

                <View className="flex-1 bg-white rounded-lg p-4">
                  <Text className="text-gray-600 text-xs font-medium mb-2">签到天数</Text>
                  <Text className="text-2xl font-bold text-secondary-600">
                    {stats?.totalCheckIns || 0}
                  </Text>
                </View>
              </View>

              <View className="flex-row justify-between gap-3">
                <View className="flex-1 bg-white rounded-lg p-4">
                  <Text className="text-gray-600 text-xs font-medium mb-2">连续签到</Text>
                  <Text className="text-2xl font-bold text-green-600">
                    {stats?.streakDays || 0} 天
                  </Text>
                </View>

                <View className="flex-1 bg-white rounded-lg p-4">
                  <Text className="text-gray-600 text-xs font-medium mb-2">平均心情</Text>
                  <Text className="text-2xl font-bold text-blue-600">
                    {emotionStats?.averageMood.toFixed(1) || '0'}/10
                  </Text>
                </View>
              </View>
            </View>

            {/* Quick Actions */}
            <View className="px-4 py-6 space-y-3">
              <Text className="text-lg font-semibold text-gray-800">快速操作</Text>

              <TouchableOpacity className="bg-primary-500 rounded-lg p-4 active:opacity-80">
                <Text className="text-white font-semibold text-center">开始咨询</Text>
              </TouchableOpacity>

              <TouchableOpacity className="bg-secondary-500 rounded-lg p-4 active:opacity-80">
                <Text className="text-white font-semibold text-center">记录情绪</Text>
              </TouchableOpacity>

              <TouchableOpacity className="bg-green-500 rounded-lg p-4 active:opacity-80">
                <Text className="text-white font-semibold text-center">每日签到</Text>
              </TouchableOpacity>
            </View>

            {/* Emotion Summary */}
            {emotionStats && (
              <View className="px-4 py-6">
                <Text className="text-lg font-semibold text-gray-800 mb-4">情绪概览</Text>

                <View className="bg-white rounded-lg p-4">
                  <View className="flex-row justify-between mb-3">
                    <Text className="text-gray-700">平均心情</Text>
                    <Text className="font-semibold text-gray-800">
                      {emotionStats.averageMood.toFixed(1)}/10
                    </Text>
                  </View>

                  <View className="flex-row justify-between mb-3">
                    <Text className="text-gray-700">平均强度</Text>
                    <Text className="font-semibold text-gray-800">
                      {emotionStats.averageIntensity.toFixed(1)}/10
                    </Text>
                  </View>

                  <View className="flex-row justify-between">
                    <Text className="text-gray-700">记录总数</Text>
                    <Text className="font-semibold text-gray-800">
                      {emotionStats.totalEntries}
                    </Text>
                  </View>
                </View>
              </View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}
