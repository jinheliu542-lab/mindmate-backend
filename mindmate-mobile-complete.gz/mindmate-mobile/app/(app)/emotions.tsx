import { useState, useEffect } from 'react'
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  TextInput,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { emotionAPI } from '@/utils/api'

interface EmotionEntry {
  id: string
  mood: number
  intensity: number
  notes: string
  date: string
}

const MOODS = ['😢', '😕', '😐', '🙂', '😄']

export default function EmotionsScreen() {
  const [entries, setEntries] = useState<EmotionEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [selectedMood, setSelectedMood] = useState(5)
  const [intensity, setIntensity] = useState(5)
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    loadEntries()
  }, [])

  const loadEntries = async () => {
    try {
      const response = await emotionAPI.getEntries()
      setEntries(response.data)
    } catch (error) {
      console.error('Failed to load entries:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async () => {
    setSubmitting(true)
    try {
      await emotionAPI.createEntry({
        mood: selectedMood,
        intensity,
        notes,
      })

      setSelectedMood(5)
      setIntensity(5)
      setNotes('')
      setShowForm(false)
      await loadEntries()
    } catch (error) {
      console.error('Failed to create entry:', error)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <ScrollView>
        {/* Header */}
        <View className="px-4 py-4 bg-white border-b border-gray-200 flex-row justify-between items-center">
          <Text className="text-2xl font-bold text-gray-800">情绪追踪</Text>
          <TouchableOpacity
            className="bg-primary-500 rounded-lg px-4 py-2"
            onPress={() => setShowForm(!showForm)}
          >
            <Text className="text-white font-semibold text-sm">
              {showForm ? '取消' : '记录'}
            </Text>
          </TouchableOpacity>
        </View>

        {showForm && (
          <View className="px-4 py-6 bg-white border-b border-gray-200">
            <Text className="text-lg font-semibold text-gray-800 mb-4">
              今天的心情如何?
            </Text>

            {/* Mood Selection */}
            <View className="mb-6">
              <View className="flex-row justify-between mb-3">
                {MOODS.map((mood, index) => (
                  <TouchableOpacity
                    key={index}
                    className={`p-3 rounded-lg ${
                      selectedMood === index + 1
                        ? 'bg-primary-100 border-2 border-primary-500'
                        : 'bg-gray-100'
                    }`}
                    onPress={() => setSelectedMood(index + 1)}
                  >
                    <Text className="text-3xl">{mood}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Intensity Slider */}
            <View className="mb-6">
              <Text className="text-sm font-medium text-gray-700 mb-2">
                强度: {intensity}/10
              </Text>
              <View className="flex-row gap-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                  <TouchableOpacity
                    key={num}
                    className={`flex-1 h-8 rounded ${
                      intensity === num
                        ? 'bg-primary-500'
                        : 'bg-gray-200'
                    }`}
                    onPress={() => setIntensity(num)}
                  />
                ))}
              </View>
            </View>

            {/* Notes */}
            <View className="mb-6">
              <Text className="text-sm font-medium text-gray-700 mb-2">
                备注 (可选)
              </Text>
              <TextInput
                className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                placeholder="记录你的想法或感受..."
                placeholderTextColor="#9ca3af"
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={4}
              />
            </View>

            {/* Submit Button */}
            <TouchableOpacity
              className="bg-primary-500 rounded-lg py-3"
              onPress={handleSubmit}
              disabled={submitting}
            >
              {submitting ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text className="text-white text-center font-semibold">
                  保存
                </Text>
              )}
            </TouchableOpacity>
          </View>
        )}

        {/* Entries List */}
        <View className="px-4 py-6">
          {loading ? (
            <View className="justify-center items-center py-12">
              <ActivityIndicator size="large" color="#0ea5e9" />
            </View>
          ) : entries.length === 0 ? (
            <View className="justify-center items-center py-12">
              <Text className="text-gray-500">还没有记录，开始记录你的情绪吧</Text>
            </View>
          ) : (
            entries.map((entry) => (
              <View
                key={entry.id}
                className="bg-white rounded-lg p-4 mb-3 border border-gray-200"
              >
                <View className="flex-row justify-between items-start mb-2">
                  <View className="flex-row items-center gap-2">
                    <Text className="text-2xl">
                      {MOODS[entry.mood - 1] || '😐'}
                    </Text>
                    <View>
                      <Text className="font-semibold text-gray-800">
                        心情指数: {entry.mood}/5
                      </Text>
                      <Text className="text-sm text-gray-600">
                        强度: {entry.intensity}/10
                      </Text>
                    </View>
                  </View>
                  <Text className="text-xs text-gray-500">
                    {new Date(entry.date).toLocaleDateString('zh-CN')}
                  </Text>
                </View>
                {entry.notes && (
                  <Text className="text-gray-700 text-sm mt-2">
                    {entry.notes}
                  </Text>
                )}
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}
