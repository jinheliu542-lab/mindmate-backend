import { useState, useEffect, useRef } from 'react'
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { chatAPI } from '@/utils/api'
import { storage } from '@/utils/storage'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

interface Conversation {
  id: string
  title: string
  messages: Message[]
}

export default function ChatScreen() {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [loading, setLoading] = useState(false)
  const [isLoadingConversations, setIsLoadingConversations] = useState(true)
  const scrollViewRef = useRef<ScrollView>(null)

  // Load conversations
  useEffect(() => {
    const loadConversations = async () => {
      try {
        const response = await chatAPI.getConversations()
        const convs = response.data
        setConversations(convs)

        if (convs.length > 0) {
          setCurrentConversationId(convs[0].id)
          await loadMessages(convs[0].id)
        }
      } catch (error) {
        console.error('Failed to load conversations:', error)
        // Load from offline storage
        const cached = await storage.getConversations()
        setConversations(cached)
      } finally {
        setIsLoadingConversations(false)
      }
    }

    loadConversations()
  }, [])

  const loadMessages = async (conversationId: string) => {
    try {
      const response = await chatAPI.getMessages(conversationId)
      setMessages(response.data)
    } catch (error) {
      console.error('Failed to load messages:', error)
      const cached = await storage.getMessages(conversationId)
      setMessages(cached)
    }
  }

  const createNewConversation = async () => {
    try {
      const response = await chatAPI.createConversation()
      const newConv = response.data
      setConversations([newConv, ...conversations])
      setCurrentConversationId(newConv.id)
      setMessages([])
    } catch (error) {
      console.error('Failed to create conversation:', error)
    }
  }

  const handleSendMessage = async () => {
    if (!inputText.trim() || !currentConversationId) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputText,
      timestamp: new Date(),
    }

    setMessages([...messages, userMessage])
    setInputText('')
    setLoading(true)

    try {
      const response = await chatAPI.sendMessage(currentConversationId, inputText)
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.data.content,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])

      // Save to offline storage
      await storage.addToSyncQueue('send_message', {
        conversationId: currentConversationId,
        message: inputText,
      })
    } catch (error) {
      console.error('Failed to send message:', error)
      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '抱歉，我现在无法回复。请稍后重试。',
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setLoading(false)
    }
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        {/* Header */}
        <View className="px-4 py-4 bg-white border-b border-gray-200 flex-row justify-between items-center">
          <Text className="text-2xl font-bold text-gray-800">AI 咨询</Text>
          <TouchableOpacity
            className="bg-primary-500 rounded-lg px-4 py-2"
            onPress={createNewConversation}
          >
            <Text className="text-white font-semibold text-sm">新对话</Text>
          </TouchableOpacity>
        </View>

        {isLoadingConversations ? (
          <View className="flex-1 justify-center items-center">
            <ActivityIndicator size="large" color="#0ea5e9" />
          </View>
        ) : (
          <>
            {/* Messages */}
            <ScrollView
              ref={scrollViewRef}
              className="flex-1 px-4 py-4"
              onContentSizeChange={() =>
                scrollViewRef.current?.scrollToEnd({ animated: true })
              }
            >
              {messages.length === 0 ? (
                <View className="flex-1 justify-center items-center py-12">
                  <Text className="text-gray-500 text-center">
                    开始一段对话吧，我会倾听并帮助你
                  </Text>
                </View>
              ) : (
                messages.map((msg) => (
                  <View
                    key={msg.id}
                    className={`mb-4 flex-row ${
                      msg.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <View
                      className={`max-w-xs rounded-lg px-4 py-3 ${
                        msg.role === 'user'
                          ? 'bg-primary-500'
                          : 'bg-white border border-gray-200'
                      }`}
                    >
                      <Text
                        className={
                          msg.role === 'user'
                            ? 'text-white'
                            : 'text-gray-800'
                        }
                      >
                        {msg.content}
                      </Text>
                    </View>
                  </View>
                ))
              )}

              {loading && (
                <View className="flex-row justify-start mb-4">
                  <View className="bg-white border border-gray-200 rounded-lg px-4 py-3">
                    <ActivityIndicator size="small" color="#0ea5e9" />
                  </View>
                </View>
              )}
            </ScrollView>

            {/* Input */}
            <View className="px-4 py-4 bg-white border-t border-gray-200 flex-row gap-2">
              <TextInput
                className="flex-1 border border-gray-300 rounded-lg px-4 py-2"
                placeholder="输入你的想法..."
                placeholderTextColor="#9ca3af"
                value={inputText}
                onChangeText={setInputText}
                editable={!loading}
                multiline
              />
              <TouchableOpacity
                className="bg-primary-500 rounded-lg px-4 py-2 justify-center"
                onPress={handleSendMessage}
                disabled={!inputText.trim() || loading}
              >
                <Text className="text-white font-semibold">发送</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}
