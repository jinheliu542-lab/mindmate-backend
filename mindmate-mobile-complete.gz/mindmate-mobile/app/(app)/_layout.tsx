import { useEffect } from 'react'
import { Tabs } from 'expo-router'
import { useAuthStore } from '@/store/authStore'
import { useRouter } from 'expo-router'

export default function AppLayout() {
  const { token } = useAuthStore()
  const router = useRouter()

  useEffect(() => {
    if (!token) {
      router.replace('/(auth)/login')
    }
  }, [token])

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopColor: '#e5e7eb',
          borderTopWidth: 1,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: '#0ea5e9',
        tabBarInactiveTintColor: '#9ca3af',
      }}
    >
      <Tabs.Screen
        name="(tabs)"
        options={{
          title: '首页',
          tabBarLabel: '首页',
        }}
      />
      <Tabs.Screen
        name="chat"
        options={{
          title: '咨询',
          tabBarLabel: '咨询',
        }}
      />
      <Tabs.Screen
        name="emotions"
        options={{
          title: '情绪',
          tabBarLabel: '情绪',
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: '个人',
          tabBarLabel: '个人',
        }}
      />
    </Tabs>
  )
}
