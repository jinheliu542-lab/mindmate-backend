import { useState, useEffect } from 'react'
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useRouter } from 'expo-router'
import { useAuthStore } from '@/store/authStore'
import { userAPI } from '@/utils/api'

interface UserStats {
  totalChats: number
  totalCheckIns: number
  streakDays: number
  joinedDate: string
}

const COUNSELING_STYLES = [
  { id: 'supportive', label: '支持型', description: '倾听和理解为主' },
  { id: 'directive', label: '指导型', description: '提供建议和方案' },
  { id: 'balanced', label: '平衡型', description: '兼具倾听和指导' },
]

export default function ProfileScreen() {
  const router = useRouter()
  const { user, logout } = useAuthStore()
  const [stats, setStats] = useState<UserStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedStyle, setSelectedStyle] = useState('balanced')
  const [focusAreas, setFocusAreas] = useState<string[]>([])
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      const response = await userAPI.getStats()
      setStats(response.data)
    } catch (error) {
      console.error('Failed to load stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSavePreferences = async () => {
    setSaving(true)
    try {
      await userAPI.updateAIPersonality(selectedStyle, focusAreas)
      Alert.alert('成功', '偏好设置已保存')
    } catch (error) {
      Alert.alert('错误', '保存失败，请重试')
    } finally {
      setSaving(false)
    }
  }

  const handleLogout = () => {
    Alert.alert('确认', '确定要退出登录吗?', [
      { text: '取消', onPress: () => {} },
      {
        text: '退出',
        onPress: async () => {
          await logout()
          router.replace('/(auth)/login')
        },
      },
    ])
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <ScrollView>
        {/* Header */}
        <View className="px-4 py-4 bg-white border-b border-gray-200">
          <Text className="text-2xl font-bold text-gray-800">个人资料</Text>
        </View>

        {loading ? (
          <View className="flex-1 justify-center items-center py-12">
            <ActivityIndicator size="large" color="#0ea5e9" />
          </View>
        ) : (
          <>
            {/* User Info */}
            <View className="px-4 py-6 bg-white border-b border-gray-200">
              <View className="mb-4">
                <Text className="text-sm text-gray-600 mb-1">用户名</Text>
                <Text className="text-xl font-semibold text-gray-800">
                  {user?.username}
                </Text>
              </View>

              <View>
                <Text className="text-sm text-gray-600 mb-1">邮箱</Text>
                <Text className="text-lg text-gray-800">{user?.email}</Text>
              </View>
            </View>

            {/* Stats */}
            {stats && (
              <View className="px-4 py-6 bg-white border-b border-gray-200">
                <Text className="text-lg font-semibold text-gray-800 mb-4">
                  统计数据
                </Text>

                <View className="flex-row justify-between gap-3 mb-3">
                  <View className="flex-1 bg-gray-50 rounded-lg p-3">
                    <Text className="text-xs text-gray-600 mb-1">总对话次数</Text>
                    <Text className="text-2xl font-bold text-primary-600">
                      {stats.totalChats}
                    </Text>
                  </View>

                  <View className="flex-1 bg-gray-50 rounded-lg p-3">
                    <Text className="text-xs text-gray-600 mb-1">签到天数</Text>
                    <Text className="text-2xl font-bold text-secondary-600">
                      {stats.totalCheckIns}
                    </Text>
                  </View>
                </View>

                <View className="flex-row justify-between gap-3">
                  <View className="flex-1 bg-gray-50 rounded-lg p-3">
                    <Text className="text-xs text-gray-600 mb-1">连续签到</Text>
                    <Text className="text-2xl font-bold text-green-600">
                      {stats.streakDays} 天
                    </Text>
                  </View>

                  <View className="flex-1 bg-gray-50 rounded-lg p-3">
                    <Text className="text-xs text-gray-600 mb-1">加入时间</Text>
                    <Text className="text-sm font-semibold text-gray-800">
                      {new Date(stats.joinedDate).toLocaleDateString('zh-CN')}
                    </Text>
                  </View>
                </View>
              </View>
            )}

            {/* AI Preferences */}
            <View className="px-4 py-6 bg-white border-b border-gray-200">
              <Text className="text-lg font-semibold text-gray-800 mb-4">
                AI 咨询偏好
              </Text>

              <Text className="text-sm text-gray-600 mb-3">咨询风格</Text>
              <View className="space-y-2 mb-6">
                {COUNSELING_STYLES.map((style) => (
                  <TouchableOpacity
                    key={style.id}
                    className={`p-3 rounded-lg border-2 ${
                      selectedStyle === style.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-gray-200 bg-gray-50'
                    }`}
                    onPress={() => setSelectedStyle(style.id)}
                  >
                    <Text className="font-semibold text-gray-800">
                      {style.label}
                    </Text>
                    <Text className="text-xs text-gray-600">
                      {style.description}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <TouchableOpacity
                className="bg-primary-500 rounded-lg py-3"
                onPress={handleSavePreferences}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text className="text-white text-center font-semibold">
                    保存偏好
                  </Text>
                )}
              </TouchableOpacity>
            </View>

            {/* Logout */}
            <View className="px-4 py-6">
              <TouchableOpacity
                className="bg-red-500 rounded-lg py-3"
                onPress={handleLogout}
              >
                <Text className="text-white text-center font-semibold">
                  退出登录
                </Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}
