import mongoose, { Schema, Document } from 'mongoose';

export interface IMessage extends Document {
  userId: mongoose.Types.ObjectId;
  conversationId: mongoose.Types.ObjectId;
  role: 'user' | 'assistant';
  content: string;
  emotionalContext?: {
    detectedMood?: string;
    sentimentScore?: number;
    keyThemes?: string[];
  };
  aiMetadata?: {
    model?: string;
    tokens?: number;
    responseTime?: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

const messageSchema = new Schema<IMessage>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    conversationId: {
      type: Schema.Types.ObjectId,
      ref: 'Conversation',
      required: true,
    },
    role: {
      type: String,
      enum: ['user', 'assistant'],
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    emotionalContext: {
      detectedMood: String,
      sentimentScore: Number,
      keyThemes: [String],
    },
    aiMetadata: {
      model: String,
      tokens: Number,
      responseTime: Number,
    },
  },
  { timestamps: true }
);

// Index for efficient querying
messageSchema.index({ userId: 1, conversationId: 1, createdAt: -1 });

export default mongoose.model<IMessage>('Message', messageSchema);
