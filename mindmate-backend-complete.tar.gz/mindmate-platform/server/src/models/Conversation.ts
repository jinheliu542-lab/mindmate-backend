import mongoose, { Schema, Document } from 'mongoose';

export interface IConversation extends Document {
  userId: mongoose.Types.ObjectId;
  title: string;
  summary?: string;
  emotionalTrend?: {
    startMood: string;
    endMood: string;
    improvement: number;
  };
  messageCount: number;
  topics: string[];
  createdAt: Date;
  updatedAt: Date;
}

const conversationSchema = new Schema<IConversation>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    title: {
      type: String,
      default: 'New Conversation',
    },
    summary: String,
    emotionalTrend: {
      startMood: String,
      endMood: String,
      improvement: Number,
    },
    messageCount: {
      type: Number,
      default: 0,
    },
    topics: [String],
  },
  { timestamps: true }
);

// Index for efficient querying
conversationSchema.index({ userId: 1, createdAt: -1 });

export default mongoose.model<IConversation>('Conversation', conversationSchema);
