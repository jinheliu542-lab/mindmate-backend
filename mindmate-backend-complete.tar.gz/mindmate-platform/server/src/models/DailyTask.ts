import mongoose, { Schema, Document } from 'mongoose';

export interface IDailyTask extends Document {
  userId: mongoose.Types.ObjectId;
  date: Date;
  tasks: {
    id: string;
    title: string;
    description: string;
    category: 'mindfulness' | 'reflection' | 'activity' | 'gratitude';
    completed: boolean;
    completedAt?: Date;
    reward?: number;
  }[];
  checkInCompleted: boolean;
  checkInTime?: Date;
  totalRewards: number;
  createdAt: Date;
  updatedAt: Date;
}

const dailyTaskSchema = new Schema<IDailyTask>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    date: {
      type: Date,
      required: true,
      default: () => {
        const date = new Date();
        date.setHours(0, 0, 0, 0);
        return date;
      },
    },
    tasks: [
      {
        id: String,
        title: String,
        description: String,
        category: {
          type: String,
          enum: ['mindfulness', 'reflection', 'activity', 'gratitude'],
        },
        completed: { type: Boolean, default: false },
        completedAt: Date,
        reward: Number,
      },
    ],
    checkInCompleted: { type: Boolean, default: false },
    checkInTime: Date,
    totalRewards: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// Index for efficient querying
dailyTaskSchema.index({ userId: 1, date: -1 });

export default mongoose.model<IDailyTask>('DailyTask', dailyTaskSchema);
