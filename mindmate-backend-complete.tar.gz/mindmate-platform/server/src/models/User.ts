import mongoose, { Schema, Document } from 'mongoose';
import bcrypt from 'bcryptjs';

export interface IUser extends Document {
  email: string;
  password: string;
  username: string;
  profile: {
    avatar?: string;
    bio?: string;
    age?: number;
    gender?: string;
  };
  emotionalProfile: {
    baselineAnxiety: number;
    baselineDepression: number;
    primaryConcerns: string[];
    coreBeliefs?: string[];
  };
  aiPersonality: {
    counselingStyle: 'supportive' | 'directive' | 'balanced';
    focusAreas: string[];
    interactionHistory: number;
  };
  stats: {
    totalChats: number;
    totalCheckIns: number;
    streakDays: number;
    lastCheckIn: Date;
  };
  createdAt: Date;
  updatedAt: Date;
  comparePassword(password: string): Promise<boolean>;
}

const userSchema = new Schema<IUser>(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
      minlength: 6,
    },
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    profile: {
      avatar: String,
      bio: String,
      age: Number,
      gender: String,
    },
    emotionalProfile: {
      baselineAnxiety: { type: Number, default: 0, min: 0, max: 10 },
      baselineDepression: { type: Number, default: 0, min: 0, max: 10 },
      primaryConcerns: [String],
      coreBeliefs: [String],
    },
    aiPersonality: {
      counselingStyle: {
        type: String,
        enum: ['supportive', 'directive', 'balanced'],
        default: 'balanced',
      },
      focusAreas: [String],
      interactionHistory: { type: Number, default: 0 },
    },
    stats: {
      totalChats: { type: Number, default: 0 },
      totalCheckIns: { type: Number, default: 0 },
      streakDays: { type: Number, default: 0 },
      lastCheckIn: Date,
    },
  },
  { timestamps: true }
);

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error as Error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function (password: string): Promise<boolean> {
  return bcrypt.compare(password, this.password);
};

export default mongoose.model<IUser>('User', userSchema);
