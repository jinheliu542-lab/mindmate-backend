import mongoose, { Schema, Document } from 'mongoose';

export interface IEmotionEntry extends Document {
  userId: mongoose.Types.ObjectId;
  date: Date;
  mood: number; // 1-10 scale
  emotions: string[]; // e.g., ['anxious', 'hopeful', 'tired']
  intensity: number; // 1-10 scale
  triggers?: string[];
  notes?: string;
  activities?: string[];
  physicalSymptoms?: string[];
  createdAt: Date;
  updatedAt: Date;
}

const emotionEntrySchema = new Schema<IEmotionEntry>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    date: {
      type: Date,
      required: true,
      default: () => new Date(),
    },
    mood: {
      type: Number,
      required: true,
      min: 1,
      max: 10,
    },
    emotions: [String],
    intensity: {
      type: Number,
      required: true,
      min: 1,
      max: 10,
    },
    triggers: [String],
    notes: String,
    activities: [String],
    physicalSymptoms: [String],
  },
  { timestamps: true }
);

// Index for efficient querying
emotionEntrySchema.index({ userId: 1, date: -1 });

export default mongoose.model<IEmotionEntry>('EmotionEntry', emotionEntrySchema);
