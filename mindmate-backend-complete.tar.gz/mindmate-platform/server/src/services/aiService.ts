import axios from 'axios';
import { IUser } from '../models/User.js';

interface AIMessage {
  role: 'user' | 'assistant';
  content: string;
}

export class AIService {
  private provider: string;
  private apiKey: string;

  constructor() {
    this.provider = process.env.AI_PROVIDER || 'deepseek';
    this.apiKey = this.getApiKey();
  }

  private getApiKey(): string {
    switch (this.provider) {
      case 'claude':
        return process.env.CLAUDE_API_KEY || '';
      case 'openai':
        return process.env.OPENAI_API_KEY || '';
      case 'deepseek':
        return process.env.DEEPSEEK_API_KEY || '';
      default:
        return '';
    }
  }

  async generateCounselingResponse(
    userMessage: string,
    conversationHistory: AIMessage[],
    userProfile: IUser
  ): Promise<string> {
    switch (this.provider) {
      case 'claude':
        return this.generateClaudeResponse(userMessage, conversationHistory, userProfile);
      case 'openai':
        return this.generateOpenAIResponse(userMessage, conversationHistory, userProfile);
      case 'deepseek':
        return this.generateDeepSeekResponse(userMessage, conversationHistory, userProfile);
      default:
        throw new Error(`Unsupported AI provider: ${this.provider}`);
    }
  }

  private async generateClaudeResponse(
    userMessage: string,
    conversationHistory: AIMessage[],
    userProfile: IUser
  ): Promise<string> {
    try {
      const systemPrompt = this.buildSystemPrompt(userProfile);

      const response = await axios.post(
        'https://api.anthropic.com/v1/messages',
        {
          model: 'claude-3-5-sonnet-20241022',
          max_tokens: 1024,
          system: systemPrompt,
          messages: [
            ...conversationHistory,
            { role: 'user', content: userMessage },
          ],
        },
        {
          headers: {
            'x-api-key': this.apiKey,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
          },
        }
      );

      const content = response.data.content[0];
      if (content.type === 'text') {
        return content.text;
      }

      throw new Error('Unexpected response format from Claude API');
    } catch (error) {
      console.error('Claude API error:', error);
      throw new Error('Failed to generate counseling response');
    }
  }

  private async generateOpenAIResponse(
    userMessage: string,
    conversationHistory: AIMessage[],
    userProfile: IUser
  ): Promise<string> {
    try {
      const systemPrompt = this.buildSystemPrompt(userProfile);

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4',
          messages: [
            { role: 'system', content: systemPrompt },
            ...conversationHistory,
            { role: 'user', content: userMessage },
          ],
          max_tokens: 1024,
          temperature: 0.7,
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return response.data.choices[0].message.content;
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw new Error('Failed to generate counseling response');
    }
  }

  private async generateDeepSeekResponse(
    userMessage: string,
    conversationHistory: AIMessage[],
    userProfile: IUser
  ): Promise<string> {
    try {
      const systemPrompt = this.buildSystemPrompt(userProfile);

      const response = await axios.post(
        'https://api.deepseek.com/chat/completions',
        {
          model: 'deepseek-chat',
          messages: [
            { role: 'system', content: systemPrompt },
            ...conversationHistory,
            { role: 'user', content: userMessage },
          ],
          max_tokens: 1024,
          temperature: 0.7,
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return response.data.choices[0].message.content;
    } catch (error) {
      console.error('DeepSeek API error:', error);
      throw new Error('Failed to generate counseling response');
    }
  }

  private buildSystemPrompt(userProfile: IUser): string {
    const style = userProfile.aiPersonality.counselingStyle;
    const concerns = userProfile.emotionalProfile.primaryConcerns.join(', ');

    let styleGuide = '';
    switch (style) {
      case 'supportive':
        styleGuide =
          'Be empathetic, validating, and supportive. Focus on emotional support and understanding.';
        break;
      case 'directive':
        styleGuide =
          'Be practical and action-oriented. Provide concrete advice and coping strategies.';
        break;
      case 'balanced':
        styleGuide =
          'Balance empathy with practical advice. Be both supportive and solution-focused.';
        break;
    }

    return `You are MindMate, an AI psychological counselor. Your role is to provide compassionate, evidence-based psychological support.

User Profile:
- Primary concerns: ${concerns}
- Counseling style preference: ${style}
- Baseline anxiety level: ${userProfile.emotionalProfile.baselineAnxiety}/10
- Baseline depression level: ${userProfile.emotionalProfile.baselineDepression}/10

Guidelines:
1. ${styleGuide}
2. Always maintain confidentiality and respect boundaries
3. Never provide medical diagnosis or replace professional therapy
4. Use evidence-based techniques (CBT, mindfulness, etc.)
5. Ask clarifying questions to better understand the user's situation
6. Provide practical coping strategies when appropriate
7. Validate emotions and experiences
8. Encourage self-reflection and personal growth
9. If the user expresses suicidal thoughts, take it seriously and encourage professional help
10. Adapt your responses based on the user's emotional state and preferences

Remember: You are supportive, non-judgmental, and focused on the user's wellbeing.`;
  }

  async analyzeSentiment(text: string): Promise<{
    mood: string;
    score: number;
    themes: string[];
  }> {
    // Simplified sentiment analysis
    // In production, use a dedicated NLP service
    const positiveWords = ['happy', 'good', 'great', 'wonderful', 'love', 'excited', 'hopeful'];
    const negativeWords = ['sad', 'bad', 'terrible', 'hate', 'anxious', 'depressed', 'worried'];

    const lowerText = text.toLowerCase();
    const positiveCount = positiveWords.filter((word) => lowerText.includes(word)).length;
    const negativeCount = negativeWords.filter((word) => lowerText.includes(word)).length;

    const score = (positiveCount - negativeCount) / (positiveCount + negativeCount + 1);

    let mood = 'neutral';
    if (score > 0.3) mood = 'positive';
    if (score < -0.3) mood = 'negative';

    return {
      mood,
      score: Math.round((score + 1) * 50), // Convert to 0-100 scale
      themes: this.extractThemes(text),
    };
  }

  private extractThemes(text: string): string[] {
    const themes: string[] = [];
    const themeKeywords: Record<string, string[]> = {
      work: ['work', 'job', 'career', 'boss', 'colleague', 'deadline', 'project'],
      relationships: ['relationship', 'friend', 'family', 'partner', 'love', 'conflict'],
      health: ['health', 'sick', 'tired', 'sleep', 'exercise', 'diet', 'pain'],
      anxiety: ['anxious', 'nervous', 'worry', 'fear', 'panic', 'stress'],
      depression: ['depressed', 'sad', 'hopeless', 'worthless', 'empty', 'numb'],
      self_esteem: ['confidence', 'self-esteem', 'worthy', 'capable', 'failure'],
    };

    const lowerText = text.toLowerCase();
    for (const [theme, keywords] of Object.entries(themeKeywords)) {
      if (keywords.some((keyword) => lowerText.includes(keyword))) {
        themes.push(theme);
      }
    }

    return themes;
  }
}

export default new AIService();
