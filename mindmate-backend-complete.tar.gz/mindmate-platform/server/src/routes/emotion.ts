import express, { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import EmotionEntry from '../models/EmotionEntry.js';

const router = express.Router();

// Create emotion entry
router.post('/entries', async (req: AuthRequest, res: Response) => {
  try {
    const { mood, emotions, intensity, triggers, notes, activities, physicalSymptoms } = req.body;

    const entry = new EmotionEntry({
      userId: req.userId,
      mood,
      emotions,
      intensity,
      triggers,
      notes,
      activities,
      physicalSymptoms,
    });

    await entry.save();
    res.status(201).json(entry);
  } catch (error) {
    console.error('Error creating emotion entry:', error);
    res.status(500).json({ error: 'Failed to create emotion entry' });
  }
});

// Get emotion entries for date range
router.get('/entries', async (req: AuthRequest, res: Response) => {
  try {
    const { startDate, endDate } = req.query;

    const query: any = { userId: req.userId };

    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate as string);
      if (endDate) query.date.$lte = new Date(endDate as string);
    }

    const entries = await EmotionEntry.find(query).sort({ date: -1 });

    res.json(entries);
  } catch (error) {
    console.error('Error fetching emotion entries:', error);
    res.status(500).json({ error: 'Failed to fetch entries' });
  }
});

// Get emotion statistics
router.get('/stats', async (req: AuthRequest, res: Response) => {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const entries = await EmotionEntry.find({
      userId: req.userId,
      date: { $gte: thirtyDaysAgo },
    }).sort({ date: 1 });

    const avgMood = entries.length > 0 ? entries.reduce((sum, e) => sum + e.mood, 0) / entries.length : 0;
    const avgIntensity = entries.length > 0 ? entries.reduce((sum, e) => sum + e.intensity, 0) / entries.length : 0;

    // Get most common emotions
    const emotionCounts: Record<string, number> = {};
    entries.forEach((entry) => {
      entry.emotions.forEach((emotion) => {
        emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
      });
    });

    const topEmotions = Object.entries(emotionCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([emotion, count]) => ({ emotion, count }));

    res.json({
      averageMood: Math.round(avgMood * 10) / 10,
      averageIntensity: Math.round(avgIntensity * 10) / 10,
      totalEntries: entries.length,
      topEmotions,
      trend: entries.map((e) => ({
        date: e.date,
        mood: e.mood,
        intensity: e.intensity,
      })),
    });
  } catch (error) {
    console.error('Error fetching emotion stats:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

export default router;
