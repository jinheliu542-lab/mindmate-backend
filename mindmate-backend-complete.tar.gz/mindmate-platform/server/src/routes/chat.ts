import express, { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import Conversation from '../models/Conversation.js';
import Message from '../models/Message.js';
import User from '../models/User.js';
import aiService from '../services/aiService.js';

const router = express.Router();

// Get all conversations
router.get('/conversations', async (req: AuthRequest, res: Response) => {
  try {
    const conversations = await Conversation.find({ userId: req.userId })
      .sort({ createdAt: -1 })
      .limit(20);

    res.json(conversations);
  } catch (error) {
    console.error('Error fetching conversations:', error);
    res.status(500).json({ error: 'Failed to fetch conversations' });
  }
});

// Create new conversation
router.post('/conversations', async (req: AuthRequest, res: Response) => {
  try {
    const { title } = req.body;

    const conversation = new Conversation({
      userId: req.userId,
      title: title || 'New Conversation',
    });

    await conversation.save();
    res.status(201).json(conversation);
  } catch (error) {
    console.error('Error creating conversation:', error);
    res.status(500).json({ error: 'Failed to create conversation' });
  }
});

// Get conversation messages
router.get('/conversations/:conversationId/messages', async (req: AuthRequest, res: Response) => {
  try {
    const { conversationId } = req.params;

    const messages = await Message.find({
      userId: req.userId,
      conversationId,
    }).sort({ createdAt: 1 });

    res.json(messages);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// Send message and get AI response
router.post('/conversations/:conversationId/messages', async (req: AuthRequest, res: Response) => {
  try {
    const { conversationId } = req.params;
    const { content } = req.body;

    if (!content || !content.trim()) {
      res.status(400).json({ error: 'Message content is required' });
      return;
    }

    // Save user message
    const userMessage = new Message({
      userId: req.userId,
      conversationId,
      role: 'user',
      content,
    });

    await userMessage.save();

    // Analyze sentiment
    const sentiment = await aiService.analyzeSentiment(content);
    userMessage.emotionalContext = {
      detectedMood: sentiment.mood,
      sentimentScore: sentiment.score,
      keyThemes: sentiment.themes,
    };
    await userMessage.save();

    // Get conversation history
    const history = await Message.find({
      userId: req.userId,
      conversationId,
    })
      .sort({ createdAt: 1 })
      .limit(10)
      .lean();

    // Get user profile for AI context
    const user = await User.findById(req.userId);
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    // Generate AI response
    const aiResponse = await aiService.generateCounselingResponse(
      content,
      history.map((msg) => ({
        role: msg.role as 'user' | 'assistant',
        content: msg.content,
      })),
      user
    );

    // Save AI response
    const assistantMessage = new Message({
      userId: req.userId,
      conversationId,
      role: 'assistant',
      content: aiResponse,
    });

    await assistantMessage.save();

    // Update conversation stats
    await Conversation.findByIdAndUpdate(conversationId, {
      $inc: { messageCount: 2 },
      $addToSet: { topics: { $each: sentiment.themes } },
    });

    // Update user stats
    await User.findByIdAndUpdate(req.userId, {
      $inc: { 'stats.totalChats': 1, 'aiPersonality.interactionHistory': 1 },
    });

    res.json({
      userMessage,
      assistantMessage,
    });
  } catch (error) {
    console.error('Error processing message:', error);
    res.status(500).json({ error: 'Failed to process message' });
  }
});

export default router;
