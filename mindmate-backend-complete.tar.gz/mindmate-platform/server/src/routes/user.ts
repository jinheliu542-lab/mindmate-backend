import express, { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import User from '../models/User.js';

const router = express.Router();

// Get user profile
router.get('/profile', async (req: AuthRequest, res: Response) => {
  try {
    const user = await User.findById(req.userId).select('-password');

    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    res.json(user);
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Update user profile
router.put('/profile', async (req: AuthRequest, res: Response) => {
  try {
    const { profile, emotionalProfile } = req.body;

    const user = await User.findByIdAndUpdate(
      req.userId,
      {
        ...(profile && { profile }),
        ...(emotionalProfile && { emotionalProfile }),
      },
      { new: true }
    ).select('-password');

    res.json(user);
  } catch (error) {
    console.error('Error updating user profile:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// Update AI personality based on interactions
router.put('/ai-personality', async (req: AuthRequest, res: Response) => {
  try {
    const { counselingStyle, focusAreas } = req.body;

    const user = await User.findByIdAndUpdate(
      req.userId,
      {
        'aiPersonality.counselingStyle': counselingStyle,
        'aiPersonality.focusAreas': focusAreas,
      },
      { new: true }
    ).select('-password');

    res.json(user);
  } catch (error) {
    console.error('Error updating AI personality:', error);
    res.status(500).json({ error: 'Failed to update AI personality' });
  }
});

// Get user statistics
router.get('/stats', async (req: AuthRequest, res: Response) => {
  try {
    const user = await User.findById(req.userId);

    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    res.json({
      totalChats: user.stats.totalChats,
      totalCheckIns: user.stats.totalCheckIns,
      streakDays: user.stats.streakDays,
      lastCheckIn: user.stats.lastCheckIn,
    });
  } catch (error) {
    console.error('Error fetching user stats:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

export default router;
