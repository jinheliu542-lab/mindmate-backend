import express, { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import DailyTask from '../models/DailyTask.js';
import User from '../models/User.js';

const router = express.Router();

// Generate daily tasks
const generateDailyTasks = () => {
  const taskTemplates = [
    {
      id: 'mindfulness',
      title: '5分钟冥想',
      description: '进行5分钟的正念冥想练习',
      category: 'mindfulness' as const,
      reward: 10,
    },
    {
      id: 'gratitude',
      title: '感恩日记',
      description: '写下今天感到感恩的三件事',
      category: 'gratitude' as const,
      reward: 10,
    },
    {
      id: 'reflection',
      title: '自我反思',
      description: '思考今天的情绪变化和触发因素',
      category: 'reflection' as const,
      reward: 15,
    },
    {
      id: 'activity',
      title: '身体活动',
      description: '进行30分钟的身体活动或运动',
      category: 'activity' as const,
      reward: 20,
    },
  ];

  return taskTemplates.slice(0, Math.floor(Math.random() * 3) + 2);
};

// Get today's tasks
router.get('/today', async (req: AuthRequest, res: Response) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let dailyTask = await DailyTask.findOne({
      userId: req.userId,
      date: today,
    });

    if (!dailyTask) {
      const tasks = generateDailyTasks();
      dailyTask = new DailyTask({
        userId: req.userId,
        date: today,
        tasks,
      });
      await dailyTask.save();
    }

    res.json(dailyTask);
  } catch (error) {
    console.error('Error fetching daily tasks:', error);
    res.status(500).json({ error: 'Failed to fetch daily tasks' });
  }
});

// Complete a task
router.put('/today/tasks/:taskId/complete', async (req: AuthRequest, res: Response) => {
  try {
    const { taskId } = req.params;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const dailyTask = await DailyTask.findOneAndUpdate(
      {
        userId: req.userId,
        date: today,
        'tasks.id': taskId,
      },
      {
        $set: {
          'tasks.$.completed': true,
          'tasks.$.completedAt': new Date(),
        },
      },
      { new: true }
    );

    if (!dailyTask) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }

    // Calculate total rewards
    const totalRewards = dailyTask.tasks
      .filter((t) => t.completed)
      .reduce((sum, t) => sum + (t.reward || 0), 0);

    await DailyTask.findByIdAndUpdate(dailyTask._id, {
      totalRewards,
    });

    res.json(dailyTask);
  } catch (error) {
    console.error('Error completing task:', error);
    res.status(500).json({ error: 'Failed to complete task' });
  }
});

// Daily check-in
router.post('/check-in', async (req: AuthRequest, res: Response) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let dailyTask = await DailyTask.findOne({
      userId: req.userId,
      date: today,
    });

    if (!dailyTask) {
      const tasks = generateDailyTasks();
      dailyTask = new DailyTask({
        userId: req.userId,
        date: today,
        tasks,
      });
    }

    dailyTask.checkInCompleted = true;
    dailyTask.checkInTime = new Date();
    await dailyTask.save();

    // Update user stats
    const user = await User.findById(req.userId);
    if (user) {
      const lastCheckIn = user.stats.lastCheckIn;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      let streakDays = user.stats.streakDays || 0;

      if (lastCheckIn) {
        const lastCheckInDate = new Date(lastCheckIn);
        lastCheckInDate.setHours(0, 0, 0, 0);

        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);

        if (lastCheckInDate.getTime() === yesterday.getTime()) {
          streakDays += 1;
        } else if (lastCheckInDate.getTime() !== today.getTime()) {
          streakDays = 1;
        }
      } else {
        streakDays = 1;
      }

      await User.findByIdAndUpdate(req.userId, {
        'stats.lastCheckIn': new Date(),
        'stats.streakDays': streakDays,
        $inc: { 'stats.totalCheckIns': 1 },
      });
    }

    res.json({
      message: 'Check-in successful',
      dailyTask,
    });
  } catch (error) {
    console.error('Error during check-in:', error);
    res.status(500).json({ error: 'Check-in failed' });
  }
});

export default router;
