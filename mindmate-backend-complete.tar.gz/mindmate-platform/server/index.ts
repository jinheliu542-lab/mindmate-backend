import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';

// Load environment variables
dotenv.config();

// Import routes
import authRoutes from './src/routes/auth.js';
import chatRoutes from './src/routes/chat.js';
import userRoutes from './src/routes/user.js';
import emotionRoutes from './src/routes/emotion.js';
import taskRoutes from './src/routes/task.js';

// Import middleware
import { errorHandler } from './src/middleware/errorHandler.js';
import { authenticateToken } from './src/middleware/auth.js';

const app: Express = express();
const PORT = process.env.SERVER_PORT || 3000;

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database Connection
const connectDB = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/mindmate';
    await mongoose.connect(mongoUri);
    console.log('✓ MongoDB connected successfully');
  } catch (error) {
    console.error('✗ MongoDB connection failed:', error);
    process.exit(1);
  }
};

// Routes
app.use('/auth', authRoutes);
app.use('/chat', authenticateToken, chatRoutes);
app.use('/user', authenticateToken, userRoutes);
app.use('/emotion', authenticateToken, emotionRoutes);
app.use('/task', authenticateToken, taskRoutes);

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use(errorHandler);

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
const startServer = async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
  });
};

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;
