# Railway 部署指南（手机操作）

本指南专为**没有电脑的用户**设计，所有步骤都可以在手机浏览器上完成。

## 📱 在手机浏览器上部署

### 步骤 1：准备工作（5分钟）

1. **获取 GitHub 账户**
   - 访问：https://github.com
   - 点击 "Sign up"
   - 使用邮箱注册
   - 验证邮箱

2. **获取 DeepSeek API 密钥**
   - 访问：https://platform.deepseek.com
   - 注册并登录
   - 获取 API 密钥（以 `sk-` 开头）
   - **保存这个密钥**

3. **获取 MongoDB 连接字符串**
   - 访问：https://www.mongodb.com/cloud/atlas
   - 注册免费账户
   - 创建集群（选择免费层）
   - 获取连接字符串
   - **格式**：`mongodb+srv://user:password@cluster.mongodb.net/mindmate`

### 步骤 2：上传代码到 GitHub（5分钟）

1. **在 GitHub 创建新仓库**
   - 登录 GitHub
   - 点击 "+" → "New repository"
   - 仓库名：`mindmate-backend`
   - 选择 "Public"
   - 点击 "Create repository"

2. **上传代码**
   - 在新仓库中，点击 "Add file" → "Upload files"
   - 上传 `/home/ubuntu/mindmate-platform/server` 文件夹中的所有文件
   - 上传 `package.json`、`tsconfig.json` 等根目录文件
   - 点击 "Commit changes"

3. **添加配置文件**
   - 在仓库中创建 `.env` 文件
   - 内容如下：

   ```
   NODE_ENV=production
   SERVER_PORT=3000
   MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/mindmate
   JWT_SECRET=your_random_secret_key_here
   DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxx
   AI_PROVIDER=deepseek
   CORS_ORIGIN=*
   ```

   - 替换实际的值
   - 点击 "Commit new file"

### 步骤 3：在 Railway 部署（10分钟）

1. **访问 Railway**
   - 打开浏览器：https://railway.app
   - 点击 "Start Project"

2. **使用 GitHub 登录**
   - 点击 "Deploy from GitHub"
   - 授权 Railway 访问您的 GitHub

3. **选择仓库**
   - 选择 `mindmate-backend` 仓库
   - 点击 "Deploy"
   - Railway 会自动部署

4. **配置环境变量**
   - 等待部署完成
   - 进入项目设置
   - 找到 "Variables"
   - 添加以下变量：

   ```
   NODE_ENV=production
   MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/mindmate
   JWT_SECRET=your_random_secret_key_here
   DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxx
   AI_PROVIDER=deepseek
   CORS_ORIGIN=*
   ```

5. **获取公网 URL**
   - 在 Railway 中找到 "Public URL"
   - 复制完整 URL（例如：`https://mindmate-api.railway.app`）
   - **保存这个 URL**

### 步骤 4：验证部署（2分钟）

1. **测试 API**
   - 在浏览器中访问：`https://your-railway-url/health`
   - 如果看到 `{"status":"ok"}`，说明部署成功

2. **检查日志**
   - 在 Railway 中查看 "Logs"
   - 确保没有错误信息

---

## 🔑 环境变量说明

| 变量名 | 说明 | 示例 |
|--------|------|------|
| `NODE_ENV` | 运行环境 | `production` |
| `SERVER_PORT` | 服务器端口 | `3000` |
| `MONGODB_URI` | MongoDB 连接字符串 | `mongodb+srv://...` |
| `JWT_SECRET` | JWT 密钥 | 任意长字符串 |
| `DEEPSEEK_API_KEY` | DeepSeek API 密钥 | `sk-...` |
| `AI_PROVIDER` | AI 提供商 | `deepseek` |
| `CORS_ORIGIN` | CORS 允许的源 | `*` |

---

## 🚀 部署完成后

1. **获取后端 URL**
   - 从 Railway 复制公网 URL
   - 例如：`https://mindmate-api.railway.app`

2. **更新移动应用配置**
   - 在 Expo 项目中设置环境变量：
   ```
   EXPO_PUBLIC_API_URL=https://mindmate-api.railway.app
   ```

3. **测试连接**
   - 在手机上打开应用
   - 尝试注册和登录
   - 测试 AI 咨询功能

---

## ❓ 常见问题

### Q: 部署失败了怎么办？

**检查清单**：
1. ✅ GitHub 仓库是否包含所有必要文件
2. ✅ `.env` 文件是否正确配置
3. ✅ MongoDB 连接字符串是否正确
4. ✅ DeepSeek API 密钥是否有效
5. ✅ Railway 日志中是否有错误信息

### Q: 如何更新代码？

1. 在 GitHub 中更新文件
2. Railway 会自动重新部署
3. 等待部署完成

### Q: 如何查看日志？

1. 进入 Railway 项目
2. 点击 "Logs"
3. 查看实时日志

### Q: 如何重新启动服务？

1. 进入 Railway 项目
2. 点击 "Redeploy"
3. 选择最新的部署
4. 点击 "Redeploy"

---

## 💰 成本

Railway 免费层包括：
- **$5 免费额度/月**
- 足以运行小型应用
- 超出部分按使用量计费

---

## 🔐 安全建议

1. **不要公开 API 密钥**
   - 不要在 GitHub 上提交包含真实密钥的 `.env` 文件
   - 使用 Railway 的环境变量功能

2. **定期检查使用量**
   - 在 DeepSeek 中监控 API 使用量
   - 在 Railway 中监控成本

3. **备份数据库**
   - 定期备份 MongoDB 数据
   - 使用 MongoDB Atlas 的备份功能

---

**部署完成！🎉**

现在您可以继续部署移动应用了。
