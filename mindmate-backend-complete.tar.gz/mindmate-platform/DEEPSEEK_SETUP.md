# DeepSeek API 集成指南

本文档提供了如何配置和使用 DeepSeek API 作为 MindMate 的 AI 提供商的详细步骤。

## 什么是 DeepSeek？

DeepSeek 是一个强大的 AI 模型提供商，提供高质量的对话和推理能力。相比其他提供商，DeepSeek 具有以下优势：

- **成本效益**：价格更低，性能优异
- **快速响应**：API 响应速度快
- **中文优化**：对中文理解和生成能力强
- **可靠性**：稳定的服务和高可用性

## 获取 DeepSeek API Key

### 步骤 1：注册账户

1. 访问 [DeepSeek 官方网站](https://www.deepseek.com)
2. 点击"注册"或"Sign Up"
3. 使用邮箱或手机号注册账户
4. 完成邮箱验证

### 步骤 2：获取 API Key

1. 登录您的 DeepSeek 账户
2. 进入 [API 控制台](https://platform.deepseek.com/api_keys)
3. 点击"创建新密钥"或"Create New API Key"
4. 复制生成的 API Key
5. **妥善保管**：不要在代码中硬编码，使用环境变量

### 步骤 3：设置充值

1. 进入账户设置 → 计费
2. 添加支付方法（支持支付宝、微信等）
3. 充值余额（建议先充值 $5-10 用于测试）

## 配置 MindMate

### 方法 1：使用环境变量（推荐）

1. **复制环境变量模板**
```bash
cp .env.example .env
```

2. **编辑 `.env` 文件**
```env
# AI 配置
AI_PROVIDER=deepseek
DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxx
```

3. **启动应用**
```bash
npm run dev
```

### 方法 2：生产环境部署

#### Vercel (前端)
```bash
# 在 Vercel 项目设置中添加环境变量
VITE_API_URL=https://your-api-domain.com
```

#### Heroku (后端)
```bash
heroku config:set AI_PROVIDER=deepseek
heroku config:set DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxx
```

#### AWS / Docker
```bash
docker run -e AI_PROVIDER=deepseek \
           -e DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxx \
           mindmate-api
```

## DeepSeek API 模型

### 可用模型

| 模型 | 描述 | 用途 |
|------|------|------|
| `deepseek-chat` | 通用对话模型 | 推荐用于心理咨询 |
| `deepseek-coder` | 代码生成模型 | 不适用于本项目 |

### 模型参数

```typescript
{
  model: 'deepseek-chat',
  messages: [...],
  max_tokens: 1024,        // 最大输出长度
  temperature: 0.7,        // 创意度 (0-1)
  top_p: 0.95,            // 核采样参数
  frequency_penalty: 0,    // 频率惩罚
  presence_penalty: 0      // 存在惩罚
}
```

## 成本估算

### DeepSeek 定价

```
输入：$0.14 / 1M tokens
输出：$0.28 / 1M tokens
```

### 月度成本示例

假设每个用户平均每天发送 10 条消息，每条消息 100 tokens：

- 100 个用户 × 10 条 × 100 tokens × 30 天 = 3M tokens
- 成本：(3M × $0.14 + 3M × $0.28) / 1M = $1.26/月

**非常经济！**

## 测试连接

### 使用 cURL 测试

```bash
curl -X POST https://api.deepseek.com/chat/completions \
  -H "Authorization: Bearer sk-xxxxxxxxxxxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-chat",
    "messages": [
      {"role": "user", "content": "你好，请自我介绍一下"}
    ],
    "max_tokens": 1024
  }'
```

### 使用 Python 测试

```python
import requests

api_key = "sk-xxxxxxxxxxxxxxxxxxxxx"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

data = {
    "model": "deepseek-chat",
    "messages": [
        {"role": "user", "content": "你好，请自我介绍一下"}
    ],
    "max_tokens": 1024
}

response = requests.post(
    "https://api.deepseek.com/chat/completions",
    headers=headers,
    json=data
)

print(response.json())
```

### 使用 Node.js 测试

```javascript
const axios = require('axios');

const apiKey = 'sk-xxxxxxxxxxxxxxxxxxxxx';

const response = await axios.post(
  'https://api.deepseek.com/chat/completions',
  {
    model: 'deepseek-chat',
    messages: [
      { role: 'user', content: '你好，请自我介绍一下' }
    ],
    max_tokens: 1024
  },
  {
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    }
  }
);

console.log(response.data);
```

## 故障排除

### 问题 1：401 Unauthorized

**原因**：API Key 无效或过期

**解决方案**：
1. 检查 API Key 是否正确复制
2. 确认 API Key 未过期
3. 在 DeepSeek 控制台重新生成 API Key

### 问题 2：429 Too Many Requests

**原因**：超过速率限制

**解决方案**：
1. 实现请求队列和重试机制
2. 增加请求间隔
3. 联系 DeepSeek 支持升级配额

### 问题 3：500 Internal Server Error

**原因**：DeepSeek 服务器错误

**解决方案**：
1. 检查请求格式是否正确
2. 稍后重试
3. 查看 DeepSeek 状态页面

### 问题 4：余额不足

**原因**：账户余额已用完

**解决方案**：
1. 进入 DeepSeek 账户充值
2. 添加支付方法
3. 充值余额

## 监控和优化

### 监控 API 使用

1. 登录 DeepSeek 控制台
2. 查看"使用统计"
3. 监控 token 使用情况和成本

### 优化成本

```typescript
// 1. 减少 max_tokens
max_tokens: 512  // 从 1024 减少到 512

// 2. 使用缓存
const cache = new Map();
if (cache.has(userMessage)) {
  return cache.get(userMessage);
}

// 3. 批量处理
// 合并多个请求为一个

// 4. 使用更短的 system prompt
// 减少不必要的上下文
```

## 切换回其他 AI 提供商

如果需要切换到 Claude 或 OpenAI：

```bash
# 切换到 Claude
AI_PROVIDER=claude
CLAUDE_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxx

# 切换到 OpenAI
AI_PROVIDER=openai
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxx
```

## 最佳实践

1. **安全性**
   - 永远不要在代码中硬编码 API Key
   - 使用环境变量
   - 定期轮换 API Key

2. **性能**
   - 实现请求缓存
   - 使用连接池
   - 监控响应时间

3. **成本控制**
   - 设置使用配额告警
   - 监控 token 消耗
   - 定期审查成本

4. **错误处理**
   - 实现重试机制
   - 记录详细日志
   - 提供用户友好的错误消息

## 获取帮助

- **DeepSeek 文档**：https://platform.deepseek.com/docs
- **API 参考**：https://platform.deepseek.com/api-docs
- **社区论坛**：https://community.deepseek.com
- **技术支持**：support@deepseek.com

## 相关资源

- [DeepSeek 官网](https://www.deepseek.com)
- [API 控制台](https://platform.deepseek.com)
- [定价信息](https://platform.deepseek.com/pricing)
- [API 文档](https://platform.deepseek.com/docs)

---

祝您使用愉快！如有问题，请参考本指南或联系 DeepSeek 支持。
