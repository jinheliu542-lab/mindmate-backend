# MindMate - AI 心理咨询平台

一个 Web 优先、响应式设计的 AI 心理咨询平台，提供实时对话咨询、情绪追踪、AI 成长机制、每日任务和心理自测工具。

## 功能特性

### 核心功能
- **实时 AI 对话咨询**：与 AI 进行深度心理咨询对话
- **AI 个性化成长**：AI 根据用户历史互动逐步调整咨询风格
- **用户账户系统**：注册/登录，数据云端存储
- **跨设备同步**：支持多设备访问，数据实时同步

### 情绪追踪
- **情绪日记**：记录每日心情、情绪、强度和触发因素
- **心理健康成长曲线**：可视化显示 30 天情绪趋势
- **情绪统计分析**：平均心情、主要情绪、情绪强度分析
- **自测评估工具**：焦虑/抑郁自测

### 每日任务系统
- **每日签到打卡**：维持使用习惯，获得奖励
- **心理小任务**：冥想、感恩日记、自我反思、身体活动
- **任务奖励系统**：完成任务解锁新功能
- **成就追踪**：连续签到天数、总对话次数统计

### 个人资料
- **用户信息管理**：年龄、性别、个人简介
- **咨询风格设置**：支持型、指导型、平衡型
- **关注领域配置**：自定义主要心理关注领域

## 技术栈

### 前端
- **框架**：React 18 + TypeScript
- **路由**：React Router v6
- **状态管理**：Zustand
- **样式**：Tailwind CSS
- **图表**：Recharts
- **构建工具**：Vite
- **HTTP 客户端**：Axios

### 后端
- **运行时**：Node.js
- **框架**：Express.js
- **数据库**：MongoDB
- **认证**：JWT (JSON Web Tokens)
- **密码加密**：bcryptjs
- **验证**：express-validator

### AI 集成
- **支持的 AI 提供商**：
  - Claude API (Anthropic)
  - OpenAI API (GPT-4)
- **可配置**：通过环境变量选择 AI 提供商

## 项目结构

```
mindmate-platform/
├── server/                 # 后端服务
│   ├── src/
│   │   ├── models/        # MongoDB 数据模型
│   │   ├── routes/        # API 路由
│   │   ├── middleware/    # 中间件
│   │   └── services/      # 业务逻辑服务
│   ├── index.ts           # 服务器入口
│   ├── package.json
│   └── tsconfig.json
├── client/                 # 前端应用
│   ├── src/
│   │   ├── pages/         # 页面组件
│   │   ├── components/    # 可复用组件
│   │   ├── store/         # 状态管理
│   │   ├── lib/           # 工具函数和 API 客户端
│   │   ├── App.tsx        # 主应用组件
│   │   └── main.tsx       # 入口文件
│   ├── index.html
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── tsconfig.json
├── .env.example           # 环境变量模板
├── package.json           # 项目根配置
└── README.md              # 本文件
```

## 快速开始

### 前置要求
- Node.js 18+ 和 npm/pnpm
- MongoDB 4.0+ (本地或云端)
- Claude API Key 或 OpenAI API Key

### 安装步骤

1. **克隆项目**
```bash
git clone <repository-url>
cd mindmate-platform
```

2. **安装依赖**
```bash
npm install
# 或
pnpm install
```

3. **配置环境变量**
```bash
cp .env.example .env
```

编辑 `.env` 文件，填入以下必要信息：
```env
# 服务器配置
SERVER_PORT=3000
NODE_ENV=development

# 数据库
MONGODB_URI=mongodb://localhost:27017/mindmate

# JWT
JWT_SECRET=your_jwt_secret_key_here_change_in_production

# AI 配置 (选择一个)
AI_PROVIDER=claude
CLAUDE_API_KEY=your_claude_api_key_here
# 或
# OPENAI_API_KEY=your_openai_api_key_here

# CORS
CORS_ORIGIN=http://localhost:5173

# 前端 API URL
VITE_API_URL=http://localhost:3000
```

4. **启动开发服务器**
```bash
npm run dev
# 或
pnpm dev
```

这将同时启动：
- 前端开发服务器：http://localhost:5173
- 后端 API 服务器：http://localhost:3000

## API 端点

### 认证 (`/auth`)
- `POST /auth/register` - 用户注册
- `POST /auth/login` - 用户登录

### 对话 (`/chat`)
- `GET /chat/conversations` - 获取所有对话
- `POST /chat/conversations` - 创建新对话
- `GET /chat/conversations/:id/messages` - 获取对话消息
- `POST /chat/conversations/:id/messages` - 发送消息并获取 AI 回复

### 用户 (`/user`)
- `GET /user/profile` - 获取用户资料
- `PUT /user/profile` - 更新用户资料
- `GET /user/stats` - 获取用户统计
- `PUT /user/ai-personality` - 更新 AI 个性化设置

### 情绪 (`/emotion`)
- `POST /emotion/entries` - 创建情绪记录
- `GET /emotion/entries` - 获取情绪记录
- `GET /emotion/stats` - 获取情绪统计

### 任务 (`/task`)
- `GET /task/today` - 获取今日任务
- `PUT /task/today/tasks/:id/complete` - 完成任务
- `POST /task/check-in` - 每日签到

## 部署指南

### 部署到 Vercel (推荐前端)

1. **前端部署**
```bash
cd client
npm run build
# 上传 dist 文件夹到 Vercel
```

2. **配置环境变量**
在 Vercel 项目设置中添加：
```
VITE_API_URL=https://your-api-domain.com
```

### 部署到 Heroku (后端)

1. **创建 Heroku 应用**
```bash
heroku create mindmate-api
```

2. **配置环境变量**
```bash
heroku config:set MONGODB_URI=<your-mongodb-uri>
heroku config:set JWT_SECRET=<your-jwt-secret>
heroku config:set CLAUDE_API_KEY=<your-claude-key>
```

3. **部署**
```bash
git push heroku main
```

### 部署到 Docker

1. **创建 Dockerfile**
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

RUN npm run build

EXPOSE 3000

CMD ["npm", "start"]
```

2. **构建并运行**
```bash
docker build -t mindmate-api .
docker run -p 3000:3000 --env-file .env mindmate-api
```

## 配置 AI 提供商

### 使用 DeepSeek API（推荐）

1. 获取 API Key：https://platform.deepseek.com/api_keys
2. 在 `.env` 中设置：
```env
AI_PROVIDER=deepseek
DEEPSEEK_API_KEY=sk-...
```
3. 详细配置指南：查看 `DEEPSEEK_SETUP.md`

### 使用 Claude API

1. 获取 API Key：https://console.anthropic.com
2. 在 `.env` 中设置：
```env
AI_PROVIDER=claude
CLAUDE_API_KEY=sk-ant-...
```

### 使用 OpenAI API

1. 获取 API Key：https://platform.openai.com/api-keys
2. 在 `.env` 中设置：
```env
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
```

## 数据模型

### User (用户)
- 基本信息：邮箱、密码、用户名
- 个人资料：头像、简介、年龄、性别
- 情绪档案：基线焦虑/抑郁水平、主要关注领域
- AI 个性化：咨询风格、关注领域、互动历史
- 统计数据：总对话数、签到数、连续签到天数

### Conversation (对话)
- 用户 ID、标题、摘要
- 情绪趋势、消息数、主题标签

### Message (消息)
- 用户 ID、对话 ID、角色、内容
- 情绪上下文：检测心情、情绪评分、关键主题
- AI 元数据：模型、令牌数、响应时间

### EmotionEntry (情绪记录)
- 用户 ID、日期、心情评分 (1-10)
- 情绪列表、强度、触发因素
- 笔记、活动、身体症状

### DailyTask (每日任务)
- 用户 ID、日期、任务列表
- 签到状态、总奖励

## 常见问题

### Q: 如何修改 AI 咨询风格？
A: 在个人资料页面选择"咨询风格偏好"，系统会根据您的选择调整 AI 的回复方式。

### Q: 数据是否安全？
A: 所有数据都通过 HTTPS 加密传输，密码使用 bcryptjs 加密存储。建议在生产环境中启用 MongoDB 的 SSL 连接。

### Q: 可以离线使用吗？
A: 不可以。该平台需要与服务器通信以使用 AI 咨询功能。

### Q: 如何导出我的数据？
A: 目前不支持数据导出。您可以通过 API 获取所有数据。

## 贡献指南

欢迎提交 Issue 和 Pull Request！

## 许可证

MIT License - 详见 LICENSE 文件

## 支持

如有问题或建议，请提交 GitHub Issue 或联系开发团队。

---

**注意**：这是一个演示项目。在生产环境中使用前，请确保：
1. 更改所有默认密钥和密码
2. 启用 HTTPS
3. 配置适当的 CORS 策略
4. 定期备份数据库
5. 监控 API 使用和成本
