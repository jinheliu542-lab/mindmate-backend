# MindMate 快速开始指南

**总耗时：约 40 分钟**

## 🎯 三个简单步骤

### 第 1 步：获取 API 密钥（5分钟）

1. 访问：https://platform.deepseek.com
2. 注册账户
3. 获取 API 密钥
4. **保存密钥**

### 第 2 步：部署后端（10分钟）

1. 访问：https://railway.app
2. 使用 GitHub 登录
3. 部署 `mindmate-backend` 仓库
4. 配置环境变量（包括 DeepSeek API 密钥）
5. **获取公网 URL**

### 第 3 步：构建和安装 APK（25分钟）

1. 访问：https://expo.dev
2. 使用 GitHub 登录
3. 创建项目并连接 `mindmate-mobile` 仓库
4. 配置 API URL（使用 Railway URL）
5. 触发 APK 构建
6. 下载 APK
7. 在手机上安装

---

## 📱 详细步骤

### 步骤 1：获取 DeepSeek API 密钥

**在手机浏览器上：**

```
1. 打开 https://platform.deepseek.com
2. 点击 "Sign Up"
3. 使用邮箱注册
4. 验证邮箱
5. 登录
6. 进入 "API Keys"
7. 点击 "Create New API Key"
8. 复制密钥（以 sk- 开头）
9. 充值 $5-10（可选但推荐）
```

**保存这个密钥！** 例如：`sk-xxxxxxxxxxxxxxxxxxxxxxxx`

---

### 步骤 2：部署后端到 Railway

**在手机浏览器上：**

#### 2.1 准备 GitHub 仓库

```
1. 访问 https://github.com
2. 登录或注册
3. 创建新仓库：mindmate-backend
4. 上传以下文件夹和文件：
   - server/ 文件夹中的所有文件
   - package.json
   - tsconfig.json
   - railway.toml
5. 创建 .env 文件，内容如下：

   NODE_ENV=production
   MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/mindmate
   JWT_SECRET=your_random_secret_key_here
   DEEPSEEK_API_KEY=sk-your_key_here
   AI_PROVIDER=deepseek
   CORS_ORIGIN=*

6. 提交文件
```

#### 2.2 在 Railway 部署

```
1. 访问 https://railway.app
2. 点击 "Start Project"
3. 选择 "Deploy from GitHub"
4. 授权 Railway 访问 GitHub
5. 选择 mindmate-backend 仓库
6. Railway 自动部署
7. 等待部署完成（2-3 分钟）
8. 找到 "Public URL"
9. 复制 URL（例如：https://mindmate-api.railway.app）
```

**保存这个 URL！** 后面会用到

---

### 步骤 3：构建和安装 APK

#### 3.1 准备 GitHub 仓库

```
1. 访问 https://github.com
2. 创建新仓库：mindmate-mobile
3. 上传以下文件夹和文件：
   - app/ 文件夹
   - src/ 文件夹
   - app.json
   - package.json
   - eas.json
   - tailwind.config.js
   - tsconfig.json
   - 等等
4. 创建 .env.production 文件，内容如下：

   EXPO_PUBLIC_API_URL=https://mindmate-api.railway.app
   EXPO_PUBLIC_APP_NAME=MindMate
   EXPO_PUBLIC_APP_VERSION=1.0.0
   EXPO_PUBLIC_ENABLE_NOTIFICATIONS=true
   EXPO_PUBLIC_ENABLE_OFFLINE_MODE=true
   EXPO_PUBLIC_DEBUG_MODE=false

   注意：用您的 Railway URL 替换 API_URL

5. 提交文件
```

#### 3.2 在 Expo 构建 APK

```
1. 访问 https://expo.dev
2. 登录或注册
3. 点击 "Create"
4. 选择 "From GitHub"
5. 授权 Expo 访问 GitHub
6. 选择 mindmate-mobile 仓库
7. 项目名称：mindmate
8. 点击 "Create project"
9. 进入项目
10. 点击 "Build"
11. 选择 "Android"
12. 选择 "APK"
13. 点击 "Build"
14. 等待构建完成（10-15 分钟）
```

#### 3.3 下载 APK

```
1. 构建完成后，Expo 会发送邮件
2. 访问 Expo 项目
3. 在 "Builds" 中找到已完成的构建
4. 点击 "Download"
5. APK 下载到手机 Downloads 文件夹
```

#### 3.4 安装 APK

```
1. 打开文件管理器
2. 进入 Downloads 文件夹
3. 找到 mindmate-*.apk 文件
4. 点击 APK 文件
5. 点击 "安装"
6. 如果提示 "未知来源"，点击 "允许"
7. 等待安装完成
8. 点击 "打开"
```

---

## 🎉 首次启动

### 创建账户

```
1. 应用启动后，看到登录屏幕
2. 点击 "注册"
3. 输入邮箱
4. 输入用户名
5. 输入密码（至少 6 个字符）
6. 点击 "注册"
7. 登录成功！
```

### 开始使用

```
1. 进入首页
2. 点击 "开始咨询" - 与 AI 对话
3. 点击 "记录情绪" - 记录心情
4. 点击 "每日签到" - 签到打卡
5. 点击 "个人" - 查看资料和统计
```

---

## 📋 需要的信息

| 项目 | 来源 | 示例 |
|------|------|------|
| DeepSeek API 密钥 | https://platform.deepseek.com | sk-xxx... |
| Railway 后端 URL | https://railway.app | https://mindmate-api.railway.app |
| MongoDB 连接字符串 | https://mongodb.com/atlas | mongodb+srv://... |
| GitHub 账户 | https://github.com | your-username |
| Expo 账户 | https://expo.dev | your-email |

---

## ✅ 检查清单

在开始前，确保您有：

- [ ] 邮箱账户
- [ ] 手机（Android 5.0 或更高）
- [ ] 网络连接
- [ ] 手机存储空间 > 500MB

---

## ❓ 常见问题

### Q: 需要电脑吗？
**A:** 不需要！所有步骤都可以在手机浏览器上完成。

### Q: 需要多少钱？
**A:** 完全免费！
- DeepSeek：按使用量计费（非常便宜）
- Railway：$5 免费额度/月
- MongoDB：免费层
- Expo：免费

### Q: 需要多长时间？
**A:** 约 40 分钟

### Q: 可以离线使用吗？
**A:** 可以！应用支持离线模式，无网络时仍可查看缓存数据。

### Q: 如何更新应用？
**A:** 
1. 在 GitHub 中更新代码
2. 在 Expo 中重新构建
3. 下载新 APK
4. 卸载旧版本，安装新版本

---

## 🆘 遇到问题？

### 问题 1：无法连接到后端

**检查**：
1. Railway 后端是否正在运行
2. API URL 是否正确
3. 网络连接是否正常

**解决**：
1. 访问 Railway 项目
2. 检查 "Logs"
3. 查看是否有错误

### 问题 2：APK 无法安装

**检查**：
1. Android 版本是否 5.0 或更高
2. 存储空间是否充足
3. 是否启用了 "未知来源"

**解决**：
1. 清理手机存储空间
2. 重新下载 APK
3. 在设置中启用 "允许安装未知来源的应用"

### 问题 3：构建失败

**检查**：
1. GitHub 仓库是否包含所有文件
2. package.json 是否正确
3. eas.json 是否存在

**解决**：
1. 查看 Expo 构建日志
2. 重新上传文件
3. 重新触发构建

---

## 📞 获取帮助

- **Expo 文档**：https://docs.expo.dev
- **Railway 文档**：https://docs.railway.app
- **DeepSeek 文档**：https://platform.deepseek.com/docs

---

## 🚀 下一步

1. **获取 API 密钥** → 5 分钟
2. **部署后端** → 10 分钟
3. **构建 APK** → 15 分钟
4. **安装应用** → 2 分钟
5. **开始使用** → 立即！

**现在就开始吧！** 🎉

---

**最后更新**：2024 年 4 月
**版本**：1.0.0
